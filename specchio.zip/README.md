# Specchio

An Italian accent trainer for iPhone and Mac. Each card is an Italian sentence spoken by your chosen ElevenLabs voice. You record yourself, compare the two pitch lines and loudness strips, rate how it went, and the app schedules the card again at a sensible interval.

- **198 sentences** covering the sounds, stress patterns, joining effects and intonation types of Standard Italian. The 50 most useful come first.
- **Spaced repetition** with the FSRS algorithm (Anki's modern scheduler). You get 10 new cards a day by default.
- **Pitch overlay** comparing the native line with yours, plus loudness strips that show consonant gaps such as doubled consonants.
- **Sound guide** with mouth diagrams, common English-speaker mistakes, and links to the cards that practise each sound.
- **Weak spots**, showing which features you rate Again or Hard most often.

## Credits

Audio for each sentence is generated the first time you see it, at about 1 credit per character. The whole set is about **5,600 credits**, so 3,000 credits covers roughly the first 100 sentences.

Every clip stays in your ElevenLabs history. Before generating anything, the app checks that history, so a sentence made on your iPhone is downloaded free on your Mac. Don't clear your ElevenLabs history, or you'll pay again for those sentences.

## Setup (about 10 minutes)

### 1. Put the app on GitHub Pages

1. On github.com, create a new **public** repository named `specchio`.
2. Click **Add file → Upload files** and drag in everything inside this folder (`index.html`, `css`, `js`, `icons`, `manifest.webmanifest`, `.nojekyll`). Commit.
3. Go to **Settings → Pages**. Under "Build and deployment", choose **Deploy from a branch**, then **main** and **/ (root)**, and save.
4. After a minute the app is live at `https://YOUR-USERNAME.github.io/specchio/`.

The code is public, but your keys are not. They are only ever stored in your own browser.

### 2. Create an ElevenLabs API key

At elevenlabs.io go to **Developers → API keys → Create**. Give the key access to:

- Text to Speech
- Speech History (read **and** write; write is needed for the Regenerate button)
- User (read; this shows your remaining credits)

Setting a credit limit on the key is a good safety net.

### 3. Create a GitHub token for syncing

Go to **github.com/settings/personal-access-tokens/new** and create a **fine-grained token**. Under **Account permissions**, set **Gists** to **Read and write** and leave everything else off. Choose an expiration you're comfortable with.

The app keeps your progress in one *secret* gist. Secret gists aren't listed anywhere, but anyone with the exact link can read them. The gist holds only card schedules, never audio or keys.

### 4. Open the app on each device

- **Mac:** open the URL in Safari or Chrome. Go to **Settings**, paste the ElevenLabs key and the GitHub token, and bookmark the page.
- **iPhone:** open the URL in Safari, tap **Share → Add to Home Screen**, and open Specchio from the home screen. Then paste both keys again in **Settings**. The home-screen app keeps its own storage, separate from Safari. Allow the microphone when asked.

## Using it

1. **Native** plays the model sentence. It also plays automatically when a card opens, which you can turn off in Settings.
2. **Record**, say the sentence, then tap **Stop**.
3. Compare the grey native line with your orange line. **A/B** plays the native sentence and then yours. **Slow** plays at 0.75× speed without changing pitch.
4. Rate it: **Again** (comes back in a minute), **Hard**, **Good** or **Easy**. Each button shows when the card will return. You can undo a rating from the message that appears.
5. Tap any feature chip on a card to open its guide page.

On a Mac you can use the keyboard: Space plays native, R records, Y plays you, A plays A/B, and 1–4 rate.

If a sentence sounds wrong, for example a missed doubling or an odd stress, tap **Regenerate**. It deletes the old clip from your ElevenLabs history and makes a new one.

## How the pitch overlay works

Pitch is measured every 10 ms with the YIN algorithm, directly on your device. Each line is converted to semitones around that speaker's own average, so a male and a female voice can be compared. Both recordings are trimmed to the speech and stretched to the same width. Gaps in a line are consonants or silence.

## Files

| Path | What it is |
|---|---|
| `js/data/sentences.js` | The sentence set (Italian, English, feature tags, what to listen for) |
| `js/data/guide.js` | Sound guide content |
| `js/srs.js` | FSRS scheduler with learning steps |
| `js/eleven.js` | ElevenLabs generation and history reuse |
| `js/progress.js` | Progress storage and GitHub Gist sync |
| `js/pitch.js`, `js/chart.js` | Pitch analysis and drawing |
| `js/recorder.js` | Microphone recording |
| `js/app.js` | The interface |

There's no build step. Edit a file, upload it, and the site updates.
