// Specchio sentence set.
// Format per line:  Italian | English | tags (space-separated) | what to listen for
// "# Section" lines group sentences. The "core" section is introduced first, in order;
// the remaining sections are interleaved round-robin so new cards stay varied.
// IDs are derived from position in this file (s001, s002 …): append new sentences at the
// END of a section only if you don't mind ids shifting — safer to append a new section.

const RAW = `
# core
Andiamo a casa, è già tardi. | Let's go home, it's already late. | rs e_open stress_penult int_statement | a casa → akkàsa; è già → èggià; già tardi → giattàrdi. The è is open.
Ho fatto tutto da solo. | I did it all by myself. | gem rs p_t_k o_open | Hold the tt in fatto and tutto. ho fatto → offàtto; da solo → dassólo.
Il treno parte alle sette e venti. | The train leaves at seven twenty. | e_open e_closed r_tap gem rs | treno and sette: open è. venti: closed é. e venti → evvénti.
Che cosa vuoi mangiare stasera? | What do you want to eat tonight? | rs int_wh o_open g_soft | che cosa → chekkòsa, with an open ò. The question starts high and falls.
Vuoi un caffè o un tè? | Do you want a coffee or a tea? | int_alt nasal_assim e_open stress_final | un caffè → ung-caffè (n turns into ng before k). Voice rises on caffè, falls on tè.
Mi passi il pane, per favore? | Can you pass me the bread, please? | p_t_k int_yesno gem r_tap | No puff of air after p. Long ss in passi. Listen to how the voice ends the question.
Ma è vero quello che dici? | But is what you're saying true? | rs int_yesno e_closed gem | è vero → èvvéro, with a closed é in vero. Hold the ll in quello.
La pizza qui è buonissima. | The pizza here is delicious. | ts gem semivowel antepenult | pizza = pit-tsa with a long ts. buo = bwo. Long ss in buonìssima.
Ho comprato tre biglietti per Roma. | I bought three tickets for Rome. | rs gli r_tap o_closed | ho comprato → okkompràto; tre biglietti → trebbigliétti. gli is always long. Roma: closed ó.
Puoi chiudere la porta? Fa freddo. | Can you close the door? It's cold. | antepenult o_open rs int_yesno int_statement | chiùdere: stress on chiu. porta: open ò. fa freddo → faffréddo.
Il tavolo è piccolo ma molto comodo. | The table is small but very comfortable. | antepenult unstressed_vowels rs o_open | tàvolo, pìccolo, còmodo: stress on the third-from-last syllable. ma molto → mammólto. Keep unstressed vowels full.
Domani mattina vado al mercato con mia madre. | Tomorrow morning I'm going to the market with my mother. | gem unstressed_vowels nasal_assim vowel_length | Long tt in mattina. con mia → kommìa. Every unstressed a stays a full a.
Sono stanco: ho dormito poco. | I'm tired: I slept very little. | nasal_assim rs o_open | stanco → stang-co. ho dormito → oddormìto. poco: open ò.
Quanto costa questo? | How much does this cost? | qu int_wh o_open | qu = kw. còsta has an open ò.
Dove abiti adesso? | Where do you live now? | antepenult linking int_wh e_open | dove‿abiti runs together. àbiti: stress on the first syllable. adesso: open è.
Ci vediamo domani alle nove. | See you tomorrow at nine. | o_open gem semivowel | Long ll in alle. nove: open ò. In vediamo, the i glides straight into a.
Scusi, sa dov'è la stazione? | Excuse me, do you know where the station is? | elision ts int_yesno rs | dov'è is one word. stazione → stattsióne: z between vowels is always long. sa dov'è → saddovè.
Non ho capito, può ripetere? | I didn't understand, can you repeat? | antepenult p_t_k int_yesno rs r_trill | ripètere: stress on pe. può ripetere → può rripètere, with a trilled r.
Mio figlio ha sei anni. | My son is six years old. | gli gem e_open hiatus | figlio: long gli. sei: open è. anni: long nn. mi-o: two separate vowels.
Il bagno è in fondo a destra. | The bathroom is at the end on the right. | gn nasal_assim rs e_open | bagno: long gn. in fondo: lower lip touches the teeth for n. a destra → addèstra, with an open è.
Abbiamo mangiato troppo stasera. | We ate too much tonight. | gem g_soft o_open | Hold bb and pp. giato = dʒato: the i is silent. troppo: open ò.
C'è un bel posto qui vicino. | There's a nice place near here. | elision apocope nasal_assim c_soft | c'è = chè. un bel → um-bel. bel is the shortened form of bello.
Anna, vieni qui un attimo! | Anna, come here a moment! | int_vocative int_command e_open antepenult | Anna: long nn. vieni: open è. àttimo: stress on the first syllable.
Ho detto martedì, non mercoledì. | I said Tuesday, not Wednesday. | int_focus rs stress_final e_closed | ho detto → oddétto. The pitch peak lands on martedì to contrast it.
Compriamo pane, latte, uova e frutta. | Let's buy bread, milk, eggs and fruit. | int_list gem o_open rs | Each item rises a little, and only the last one falls. uova: open ò. e frutta → effrùtta.
Se vieni con noi, ti offro un gelato. | If you come with us, I'll buy you an ice cream. | int_continuation rs nasal_assim o_open | The first half stays up because it's unfinished. se vieni → sevviéni. con noi → konnói. offro: open ò.
Che bella giornata! | What a beautiful day! | int_exclaim rs e_open | che bella → chebbèlla, with an open è. Starts high and falls strongly.
Perché non mi hai chiamato? | Why didn't you call me? | int_wh stress_final e_closed linking rs | perché: closed é, stress at the end. perché non → perchénnon. mi‿hai runs together.
Lavoro in un ufficio in centro. | I work in an office downtown. | linking gem c_soft | in‿un‿ufficio runs together. ufficio: long ff, and cio = cho.
Non lo so, forse sì. | I don't know, maybe yes. | o_open stress_final int_statement | so: open ò. forse: closed ó. sì is short and clipped.
Dobbiamo partire subito. | We have to leave right away. | antepenult stress_contrast gem r_tap | sùbito: stress on the first syllable (subìto means 'undergone'). Long bb.
Mia sorella vive a Napoli. | My sister lives in Naples. | antepenult rs gem e_open | a Napoli → annàpoli. sorella: open è, long ll.
Hai visto il film ieri sera? | Did you see the film last night? | int_yesno e_open e_closed semivowel | ieri: open è. sera: closed é. Listen for the difference.
Prendo un bicchiere d'acqua, grazie. | I'll have a glass of water, thanks. | elision qu ts nasal_assim gem e_open | un bicchiere → um-bicchiere. d'acqua: cq = a long kk + w. grazie → grattsie.
Il gatto dorme sul letto. | The cat is sleeping on the bed. | gem e_open o_open r_tap | gatto, letto: long tt. letto: open è. dorme: open ò.
Siamo arrivati in anticipo. | We arrived early. | antepenult linking r_trill | arrivati: trilled rr. in‿anticipo runs together. antìcipo: stress on ti.
Quest'anno andiamo in Sicilia. | This year we're going to Sicily. | elision linking c_soft | quest'anno is one word. Sicilia: ci = chi, li-a glides.
Mi piace molto questa canzone. | I really like this song. | c_soft ts o_closed | piace: ce = che. canzone: z after n = ts. molto: closed ó.
Lo zio di Giorgio è medico. | Giorgio's uncle is a doctor. | ts g_soft antepenult hiatus | zio = tsi-o. Giorgio: two dʒ sounds with no i. mèdico: stress on the first syllable.
Il prezzo è troppo alto per me. | The price is too high for me. | ts gem e_open o_open rs | prezzo: open è and a long ts. è troppo → ettròppo, with an open ò.
Ci vediamo fra tre giorni. | See you in three days. | rs g_soft o_closed | fra tre → fratt-tre. tre giorni → treggiórni. giorno: closed ó.
È meglio aspettare un po'. | It's better to wait a bit. | gli e_open rs apocope | è meglio → èmmeglio. meglio: open è, long gli. po' is short for poco.
Mi sono svegliato alle sei. | I woke up at six. | s_voicing gli e_open | sv in svegliato is pronounced zv. Long gli. sei: open è.
Ma dove sei stato tutto il giorno? | Where have you been all day? | rs int_wh e_open linking | ma dove → maddóve. sei: open è. tutto‿il runs together.
Il cane abbaia ogni notte. | The dog barks every night. | gem_contrast gn o_open semivowel | cane has a single n. abbaia: long bb + glide. ogni: long gn. notte: open ò, long tt.
Gli amici arrivano domenica. | Our friends arrive on Sunday. | gli antepenult r_trill e_closed | gli amici: soft gli. arrìvano, doménica: stress on the third-from-last syllable.
Telefonano sempre all'ora di cena. | They always call at dinnertime. | stress_4th elision c_soft e_open e_closed | telèfonano: stress on le, four syllables from the end. sempre: open è. cena: closed é.
Non è facile parlare bene. | It's not easy to speak well. | antepenult e_open r_tap rs | è facile → èffàcile. bene: open è. In parlare, the r before l is a quick tap.
Questo vino è buono, ma quello è migliore. | This wine is good, but that one is better. | int_continuation gli o_open rs | The first half stays up. è buono → èbbuòno, with an open ò. migliore: long gli, closed ó.
Un po' di pazienza, per favore. | A little patience, please. | apocope ts nasal_assim e_open | un po' → um-pò. pazienza → pattsiènza, with an open è.

# geminates
Non ho detto caro, ho detto carro. | I didn't say 'dear', I said 'cart'. | gem_contrast r_trill r_tap int_focus | caro: one quick tap. carro: a full trill. The contrast carries the peak.
Il nonno abita al nono piano. | Grandpa lives on the ninth floor. | gem_contrast antepenult o_open | nonno: long nn. nono: single n. Both have an open ò.
Ho sete, e sono le sette. | I'm thirsty, and it's seven o'clock. | gem_contrast e_closed e_open | sete: closed é, single t. sette: open è, long tt.
Prendi la palla, non la pala. | Take the ball, not the shovel. | gem_contrast int_command int_focus | palla: hold the ll. pala: short l.
Ho messo il cappello sui capelli. | I put the hat on my hair. | gem_contrast e_open e_closed | cappello: long pp, open è. capelli: single p, closed é.
Ho fatto una copia per la coppia. | I made a copy for the couple. | gem_contrast o_open o_closed | copia: single p, open ò. coppia: long pp, closed ó.
Ho sonno, ma sono felice. | I'm sleepy, but I'm happy. | gem_contrast o_closed | sonno: long nn. sono: single n.
Che pena, ho perso la penna! | What a shame, I lost my pen! | gem_contrast int_exclaim rs | pena: single n. penna: long nn. che pena → cheppéna.
Ecco l'eco della montagna. | Here's the echo from the mountain. | gem_contrast elision e_open gn | ecco: long kk. eco: single k. Both have an open è.
Paghi alla cassa, non a casa. | You pay at the checkout, not at home. | gem_contrast rs | cassa: long ss. a casa → akkàsa (the k doubles, the s doesn't).
Il cammino è lungo, ma il camino è caldo. | The path is long, but the fireplace is warm. | gem_contrast nasal_assim | cammino: long mm. camino: single m. lungo → lung-go.
Di sera lavoro nella serra. | In the evening I work in the greenhouse. | gem_contrast r_trill r_tap e_closed e_open | sera: one tap, closed é. serra: trill, open è.
Scrivo le note di notte. | I write the notes at night. | gem_contrast o_open | note: single t. notte: long tt. Both have an open ò.

# raddoppiamento
Vado a Milano e poi a Torino. | I'm going to Milan and then to Turin. | rs | a Milano → ammilàno. e poi → eppói. a Torino → attorìno.
Chi sei? Non ti conosco. | Who are you? I don't know you. | rs int_wh o_closed | chi sei → chissèi. conosco: closed ó.
Va bene, facciamo così. | OK, let's do it this way. | rs c_soft gem stress_final | va bene → vabbène. facciamo: long ch. così: stress at the end.
Più tardi ti chiamo. | I'll call you later. | rs ch_gh | più tardi → piuttàrdi. chi = k + glide.
Firenze è una città bellissima. | Florence is a very beautiful city. | rs ts e_open stress_final | città bellissima → cittàbbellìssima. Firenze: ts after n, open è.
Lo faccio da solo, grazie. | I'll do it myself, thanks. | rs c_soft ts | da solo → dassólo. faccio: long ch. grazie → grattsie.
Come te non c'è nessuno. | There's nobody like you. | rs elision e_closed | come te → comettè. c'è = chè.
Tra poco arriva il treno. | The train is arriving shortly. | rs r_trill o_open e_open | tra poco → trappòco. arriva: trilled rr.
Sopra la sedia c'è una giacca. | There's a jacket on the chair. | rs elision gem e_open | sopra la → sopralla. giacca: long kk. sedia: open è.
Qualche volta mangio fuori. | Sometimes I eat out. | rs o_open semivowel qu | qualche volta → qualchevvòlta. fuori = fwòri, with an open ò.
Ho visto tre gatti e due cani. | I saw three cats and two dogs. | rs | ho visto → ovvìsto. tre gatti → treggàtti. e due → eddùe.
Partirò domani, però torno presto. | I'm leaving tomorrow, but I'll be back soon. | stress_final rs e_open | partirò, però: stress on the last syllable. però torno → peròttórno. presto: open è.
Ma dai, non ci credo! | Come on, I don't believe it! | rs int_exclaim | ma dai → maddài. Big pitch swing.
Di solito vado a scuola a piedi. | I usually walk to school. | rs semivowel e_open | No doubling after di, and none before s + consonant (a scuola). a piedi → appièdi.

# elision
Dov'è l'albergo? | Where's the hotel? | elision int_wh e_open | dov'è and l'albergo each run together. albergo: open è.
Com'è andata l'altra sera? | How did it go the other evening? | elision int_wh | com'è‿andata flows as one unit.
Quand'è il tuo compleanno? | When is your birthday? | elision nasal_assim gem int_wh hiatus | quand'è. compleanno: m before p, e-a as two vowels, long nn.
D'accordo, ci vediamo all'una. | Agreed, see you at one. | elision gem | d'accordo: long kk. all'una is one word.
Quell'uomo è un bravo attore. | That man is a good actor. | elision semivowel o_open r_tap gem | uomo = wòmo, with an open ò. attore: long tt.
Buongiorno, signor Rossi. | Good morning, Mr Rossi. | apocope o_closed int_vocative gn | signor is the shortened form. giorno, Rossi: closed ó.
Il dottor Bianchi è in ferie. | Dr Bianchi is on holiday. | apocope nasal_assim e_open | dottor is shortened. Bianchi → biang-ki. ferie: open è.
Ti voglio bene, mamma. | I love you, Mum. | gli o_open e_open int_vocative gem | voglio: open ò, long gli. bene: open è. mamma: long mm.
Voler bene è facile, capire è difficile. | Loving is easy, understanding is hard. | apocope antepenult rs | voler is shortened. è facile → èffàcile. difficile: stress on fì.
Ho mal di testa da stamattina. | I've had a headache since this morning. | apocope rs e_open | mal is shortened. ho mal → ommàl. No doubling before st. testa: open è.

# nasals
Non posso venire con voi. | I can't come with you. | nasal_assim o_open | non posso → nom-pòsso. con voi → kon-voi, with lip touching teeth. posso: open ò.
Mangio sempre un panino a pranzo. | I always have a sandwich for lunch. | nasal_assim ts g_soft | un panino → um-panino. pranzo: ts after n.
Sono in banca, ti richiamo dopo. | I'm at the bank, I'll call you back later. | nasal_assim o_closed | in banca → im-bang-ka. dopo: closed ó.
Anche in inverno fa caldo. | Even in winter it's warm. | nasal_assim linking rs e_open | anche → ang-ke. inverno: n with lip on teeth, open è. fa caldo → faccàldo.
Un gatto nero dorme in giardino. | A black cat is sleeping in the garden. | nasal_assim e_closed o_open | un gatto → ung-gatto. nero: closed é. dorme: open ò.

# stress
Il numero di telefono è sbagliato. | The phone number is wrong. | antepenult s_voicing gli | nùmero, telèfono. sb in sbagliato is pronounced zb.
Ho letto l'ultima pagina del libro. | I read the last page of the book. | antepenult elision rs | ùltima, pàgina. ho letto → ollètto.
Ancora non so dove mettere l'ancora. | I still don't know where to put the anchor. | stress_contrast antepenult | ancóra (still) vs àncora (anchor). mèttere.
I principi del principe sono strani. | The prince's principles are strange. | stress_contrast antepenult | princìpi (principles) vs prìncipe (prince).
Hai capito subito? | Did you understand right away? | stress_contrast antepenult int_yesno | capìto, then sùbito with stress on the first syllable.
Ordinano sempre la stessa cosa. | They always order the same thing. | stress_4th o_open e_closed | òrdinano: stress four syllables from the end. stessa: closed é. cosa: open ò.
Portamelo domani, per favore. | Bring it to me tomorrow, please. | stress_4th int_command o_open | pòrtamelo: the stress stays on por.
Dimmelo subito! | Tell me right now! | antepenult gem int_command | dìmmelo: long mm. sùbito.
La musica classica mi rilassa. | Classical music relaxes me. | antepenult gem | mùsica, clàssica. rilassa: long ss.
Sabato andiamo al lago. | On Saturday we're going to the lake. | antepenult vowel_length | sàbato. lago: the stressed a is long.
La casa di Marta è vicino al mare. | Marta's house is near the sea. | vowel_length r_tap | càsa, màre: a stressed vowel at the end of a syllable is longer. Marta: shorter a before rt.
Paolo ha paura del buio. | Paolo is afraid of the dark. | hiatus semivowel vowel_length | pa-o-lo, pa-ù-ra: each vowel is a full beat. buio: u + glide.

# vowels
Mangio una pesca e vado a pesca. | I eat a peach and go fishing. | e_open e_closed rs | pèsca (peach): open è. pésca (fishing): closed é. a pesca → appésca.
La botte è piena di vino. | The barrel is full of wine. | o_closed e_open semivowel | botte (barrel): closed ó. piena: open è.
Il vecchio pescatore guarda il mare. | The old fisherman looks at the sea. | e_open o_closed gem qu | vecchio: open è, long kk. pescatore: closed ó.
Questo è il mio nome. | This is my name. | o_closed e_closed hiatus | questo: closed é. nome: closed ó. mi-o: two vowels.
Che ore sono? Sono le otto. | What time is it? It's eight o'clock. | o_closed o_open gem int_wh | ore: closed ó. otto: open ò, long tt.
Il cielo è sereno oggi. | The sky is clear today. | e_open e_closed o_open g_soft | cielo: open è (cie = chè). sereno: closed é. oggi: open ò, long dʒ.
Ieri il tempo era bellissimo. | Yesterday the weather was beautiful. | e_open semivowel antepenult | ieri, tempo, era: all open è.
Il sole è rosso stasera. | The sun is red tonight. | o_closed e_closed | sole, rosso: closed ó. sera: closed é.
Nove persone sono nuove qui. | Nine people are new here. | o_open o_closed semivowel | nove, nuove: open ò. persone: closed ó.
Il ferro è freddo. | The iron is cold. | e_open e_closed r_trill | ferro: open è + trill. freddo: closed é.
Tutti sono usciti di corsa. | Everyone rushed out. | u sc o_closed gem | u is tight and fully rounded. usciti: long sh. corsa: closed ó.
Il fiume scorre sotto il ponte. | The river flows under the bridge. | u r_trill semivowel o_closed | fiume: pure u with no 'yoo'. scorre: trill. sotto, ponte: closed ó.
Luca usa una tuta blu. | Luca wears a blue tracksuit. | u stress_final | Every u stays rounded and steady. blu ends crisply.
Vivi in una villa? | Do you live in a villa? | i gem int_yesno linking | i is short and pure, never 'ih'. villa: long ll.
Marta mangia la banana alla mattina. | Marta eats the banana in the morning. | a unstressed_vowels | Every a stays open and full, with no 'uh' even when unstressed.
La lavatrice è rotta di nuovo. | The washing machine is broken again. | unstressed_vowels o_closed o_open | lavatrice: keep every a full. rotta: closed ó. nuovo: open ò.
Preferisco la cioccolata calda. | I prefer hot chocolate. | unstressed_vowels c_soft gem | pre-fe-ri: keep the unstressed e's. cioccolata: long kk.
Il presidente ha parlato al telegiornale. | The president spoke on the TV news. | unstressed_vowels g_soft r_tap | Lots of unstressed e and a: keep each one clear.
Le persone parlano velocemente. | People speak quickly. | unstressed_vowels antepenult c_soft | pàrlano. velocemente: every e stays e.
Il latte, il pane e il miele. | Milk, bread and honey. | final_vowels int_list e_open | Every final e is clear, never swallowed. miele: open è.
Ogni mattina prendo il caffè al bar. | Every morning I have coffee at the bar. | final_vowels gn stress_final r_tap | ogni: long gn. Final vowels stay full. bar ends on a tap.

# consonants
Paolo prende il tè con Pietro. | Paolo has tea with Pietro. | p_t_k semivowel nasal_assim e_open | No puff on p and t. con Pietro → kom-pietro. Pietro: open è.
Che caldo! Prendo un gelato al cocco. | So hot! I'll have a coconut ice cream. | p_t_k int_exclaim gem o_open | c = k with no puff. cocco: long kk, open ò.
Tanti auguri, Teresa! | Happy birthday, Teresa! | p_t_k int_exclaim int_vocative dental | t at the teeth with no puff. The voice rises to Teresa.
Bevo da un bicchiere di vetro. | I drink from a glass. | b_d_g nasal_assim e_open | b, d, v voiced from the very start. bicchiere: open è. vetro: closed é.
Dammi due dadi, dai. | Give me two dice, come on. | b_d_g dental gem | d at the teeth, voiced throughout. dammi: long mm.
Gianni gioca a golf con Guido. | Gianni plays golf with Guido. | b_d_g g_soft rs semivowel nasal_assim | a golf → aggòlf. Guido = gwido. con Guido → kong-gwido.
Tutti i dentisti sono di Torino. | All the dentists are from Turin. | dental | t, d, n: the tongue tip touches the back of the upper teeth.
Lei legge un libro nel letto. | She reads a book in bed. | dental e_open | l is clear, never the dark l of 'ball'. legge, letto: open è.
Il lunedì lavoro fino alle sette. | On Monday I work until seven. | dental stress_final gem | l stays light at the end of words too (il, nel).
Rita arriva in ritardo alla riunione. | Rita is arriving late for the meeting. | r_trill r_tap hiatus | A word-initial r and rr are trilled. r between vowels is one tap.
Raramente ricordo i sogni. | I rarely remember my dreams. | r_trill r_tap gn o_open | The first r is trilled, the middle r is a tap. sogni: long gn.
Il treno per Trieste è in ritardo. | The train to Trieste is late. | r_tap r_trill e_open | tr: tap straight after t, never 'chr'. Trieste: open è.
Mario porta tre fiori a sua moglie. | Mario is bringing his wife three flowers. | r_tap gli rs | The r in porta is short. a sua → assùa. moglie: long gli.
Arrivederci, a domani! | Goodbye, see you tomorrow! | r_trill rs c_soft int_exclaim | arrivederci: trilled rr, tap before ch. a domani → addomàni.
Corro ogni mattina nel parco. | I run every morning in the park. | r_trill gn gem | corro: a full trill. ogni: long gn.
Voglio una bottiglia di olio. | I want a bottle of oil. | gli o_open gem | voglio, bottiglia: long gli. olio is l + glide, not gli.
La famiglia di Guglielmo è grande. | Guglielmo's family is big. | gli semivowel | gli is long and soft, with the tongue flat on the palate.
Mangiamo gli gnocchi con il ragù. | We're having gnocchi with ragù. | gn gli stress_final o_open | gli gnocchi: gn is long even at the start of a word. ragù: stress at the end.
Il signore ha un bagno grande. | The gentleman has a big bathroom. | gn | gn is always long between vowels: siɲ-ɲore, baɲ-ɲo.
Lo sciopero è finito ieri. | The strike ended yesterday. | sc antepenult o_open | lo sciopero → loʃʃòpero (long sh after a vowel). sciòpero: stress on the first syllable.
Esci, lascia stare il pesce. | Go out, leave the fish alone. | sc int_command | sh is long between vowels: eʃ-ʃi, laʃ-ʃa, peʃ-ʃe.
La scena era bellissima. | The scene was beautiful. | sc e_open | la scena → laʃʃèna: long even across the word boundary.
Lo zucchero è nella dispensa. | The sugar is in the pantry. | dz gem | zucchero starts with a voiced dz. Long kk.
È mezzogiorno, ora di pranzo. | It's noon, lunch time. | dz ts o_closed | mezzogiorno: long voiced ddz. pranzo: voiceless ts.
Hai fatto una bella azione. | You did a good deed. | ts e_open | azione: z between vowels is always long (attsióne).
Il ragazzo canta una canzone. | The boy is singing a song. | ts gem | ragazzo: long ts. canzone: ts after n.
Zanzare a zero gradi? Impossibile. | Mosquitoes at zero degrees? Impossible. | dz int_yesno nasal_assim e_open | zanzare: both z are voiced (dz). zero: open è. In impossibile, the m comes before p.
Ciao, ci vediamo in centro. | Hi, see you downtown. | c_soft | ci and ce = ch. ciao: no i sound, just chao.
Giovanni mangia una ciliegia. | Giovanni is eating a cherry. | g_soft c_soft e_open | gio, gia: the i is silent. ciliegia: open è.
Chiara cerca la chiave in cucina. | Chiara is looking for the key in the kitchen. | ch_gh c_soft p_t_k | chi = k + glide. ce, ci = ch.
Il ghiaccio è nel bicchiere. | The ice is in the glass. | ch_gh c_soft gem | ghi = hard g + glide. ghiaccio: long ch.
Questa giacca è troppo cara. | This jacket is too expensive. | qu g_soft gem rs | qu = kw. giacca: long kk. è troppo → ettròppo.
Qual è la tua squadra preferita? | What's your favourite team? | qu int_wh | qual è flows together. squadra: kw.
Il vento soffia forte. | The wind is blowing hard. | f_v gem e_open o_open | vento: open è. soffia: long ff. forte: open ò.
Sbaglio sempre strada. | I always take the wrong road. | s_voicing gli | sb = zb. strada: s stays voiceless before t.
Smetti di fumare, dai! | Stop smoking, come on! | s_voicing int_command | sm in smetti is pronounced zm.
Svegliati, sono le nove! | Wake up, it's nine o'clock! | s_voicing gli int_command antepenult | sv = zv. svègliati: stress on sve.
Il cuoco ha cucinato il pesce. | The cook cooked the fish. | semivowel o_open sc | cuoco = kwòko, with an open ò. pesce: long sh.
Siamo in Piemonte da sei mesi. | We've been in Piedmont for six months. | semivowel e_open e_closed | pie = pye. sei: open è. mesi: closed é.
La paura fa novanta. | Fear makes you do crazy things. | hiatus rs | pa-ù-ra: three syllables. fa novanta → fannovànta.
Lui è mio zio. | He's my uncle. | hiatus ts | lu-i, mi-o, zi-o: each vowel is its own beat.
L'aereo è in orario. | The plane is on time. | hiatus elision linking | a-è-re-o: four syllables, none skipped.
Io e Laura andiamo in Europa. | Laura and I are going to Europe. | hiatus semivowel o_open | Lau = la + u glide. Europa: open ò.
Mi hanno detto che arrivi oggi. | They told me you're arriving today. | linking rs | mi‿hanno run together. che‿arrivi: no doubling before a vowel.
Ci andiamo insieme alle otto. | We're going there together at eight. | linking gem e_open | ci‿andiamo. alle‿otto. insieme: open è.
Tutto era pronto alle undici. | Everything was ready at eleven. | linking antepenult | tutto‿era. ùndici.

# intonation
Vieni anche tu? | Are you coming too? | int_yesno nasal_assim | A yes/no question. Listen to the end: northern and neutral speakers rise, while Rome and the south rise then fall.
Vieni anche tu. | You're coming too. | int_statement nasal_assim | Same words as a statement: it falls at the end. Compare with the previous card.
Dove vai? A casa? | Where are you going? Home? | int_wh int_yesno rs | dove vai falls. a casa? rises.
Hai fame, vero? | You're hungry, aren't you? | int_tag | The tag vero? rises sharply.
Ti piace il mare o la montagna? | Do you like the sea or the mountains? | int_alt gn | Rises on mare, falls on montagna.
Ho comprato mele, pere, arance e limoni. | I bought apples, pears, oranges and lemons. | int_list rs | Each item rises a little, and only limoni falls.
Quando arrivo a casa, ti chiamo. | When I get home, I'll call you. | int_continuation rs | The voice stays up on casa (unfinished), then falls on chiamo.
Siediti e aspetta qui. | Sit down and wait here. | int_command semivowel e_open antepenult | sièditi. Commands fall firmly at the end.
Che bello vederti! | How lovely to see you! | int_exclaim rs e_open | che bello → chebbèllo. High start, strong fall.
Non lo voglio, l'ho già detto! | I don't want it, I already said so! | int_exclaim gli elision rs | l'ho. già detto → giaddétto.
È arrivato Marco, non Luca. | Marco arrived, not Luca. | int_focus | The pitch peak goes on Marco. Luca stays low and flat.
Signora, ha dimenticato la borsa! | Madam, you forgot your bag! | int_vocative int_exclaim gn | The call Signora has its own melody. borsa: closed ó.
Ragazzi, si mangia! | Guys, food's ready! | int_vocative g_soft ts | ragazzi: long ts. A calling melody.
Davvero? Non ci posso credere. | Really? I can't believe it. | int_yesno antepenult gem | davvero: long vv. crédere: stress on cre.
Ma come, sei già qui? | What, you're already here? | int_yesno int_exclaim rs | A surprised question, higher and wider. ma come → makkóme.
Prego, si accomodi. | Please, have a seat. | int_command antepenult gem | accòmodi: stress on co, long kk.
Allora, che facciamo stasera? | So, what are we doing tonight? | int_wh rs gem | allora: long ll, and the voice stays up. che facciamo → cheffacciàmo.
Se avessi più tempo, studierei di più. | If I had more time, I'd study more. | int_continuation rs e_open | più tempo → piuttèmpo, with an open è.
Quando ero piccolo, abitavo vicino al mare. | When I was little, I lived near the sea. | int_continuation antepenult linking | quando‿ero. pìccolo. Up on piccolo, down on mare.
Non mi ricordo dove ho messo le chiavi. | I can't remember where I put the keys. | linking o_open e_closed | dove‿ho run together. ricordo: open ò. messo: closed é.
Ho perso l'autobus e sono arrivato tardi. | I missed the bus and arrived late. | elision antepenult semivowel rs | àutobus: stress on au. ho perso → oppèrso.
Il mio appartamento è al terzo piano. | My apartment is on the third floor. | gem ts e_open | appartamento: long pp. terzo: ts after r, open è.
Vorrei un tavolo per due, per favore. | I'd like a table for two, please. | r_trill e_open antepenult | vorrei: trilled rr, open è. tàvolo.
Posso pagare con la carta? | Can I pay by card? | int_yesno o_open | posso: open ò, long ss.
Il conto, per favore. | The bill, please. | o_closed | conto: closed ó.
Che tempo fa domani? | What's the weather like tomorrow? | int_wh rs e_open | che tempo → chettèmpo. fa domani → faddomàni.
Mi raccomando, chiamami quando arrivi. | Please, call me when you arrive. | int_command gem antepenult | raccomando: long kk. chiàmami.
`;

function parse(raw) {
  const sections = [];
  let cur = null;
  for (const line0 of raw.split('\n')) {
    const line = line0.trim();
    if (!line) continue;
    if (line.startsWith('#')) {
      cur = { name: line.slice(1).trim(), items: [] };
      sections.push(cur);
      continue;
    }
    const [it, en, tags, note] = line.split('|').map(s => (s || '').trim());
    cur.items.push({ it, en, tags: tags.split(/\s+/).filter(Boolean), note, section: cur.name });
  }
  // assign stable ids by file position
  let n = 0;
  for (const s of sections) for (const c of s.items) c.id = 's' + String(++n).padStart(3, '0');
  // introduction order: core in order, then round-robin across the other sections
  const order = [...sections[0].items];
  const rest = sections.slice(1).map(s => [...s.items]);
  while (rest.some(q => q.length)) for (const q of rest) if (q.length) order.push(q.shift());
  order.forEach((c, i) => (c.order = i));
  return order;
}

export const SENTENCES = parse(RAW);
export const SENTENCE_BY_ID = Object.fromEntries(SENTENCES.map(s => [s.id, s]));
