// Review progress: kept in localStorage on each device and synced through a private
// GitHub Gist so the iPhone and the Mac share one schedule.

import { ls } from './store.js';

const FILE = 'specchio-progress.json';
const GH = 'https://api.github.com';

export function emptyProgress() {
  return { v: 1, cards: {}, log: [], settings: { newPerDay: 10, t: 0 } };
}

// Merge two progress objects. Each card keeps whichever copy was changed last;
// review logs are unioned by id; settings keep the newest.
export function merge(a, b) {
  a = a || emptyProgress();
  b = b || emptyProgress();
  const out = emptyProgress();
  const ids = new Set([...Object.keys(a.cards || {}), ...Object.keys(b.cards || {})]);
  for (const id of ids) {
    const x = a.cards?.[id], y = b.cards?.[id];
    out.cards[id] = !x ? y : !y ? x : ((y.t || 0) > (x.t || 0) ? y : x);
  }
  const seen = new Map();
  for (const e of [...(a.log || []), ...(b.log || [])]) if (!seen.has(e.id)) seen.set(e.id, e);
  out.log = [...seen.values()].sort((p, q) => p.ts - q.ts);
  const sa = a.settings || {}, sb = b.settings || {};
  out.settings = { ...emptyProgress().settings, ...((sb.t || 0) > (sa.t || 0) ? sb : sa) };
  return out;
}

export const progressStore = {
  load: () => {
    const p = ls.get('progress', null);
    return p ? merge(p, null) : emptyProgress();
  },
  save: p => ls.set('progress', p),
};

// ── GitHub Gist sync ──
export function syncConfig() {
  return { token: ls.get('ghToken', ''), gistId: ls.get('gistId', '') };
}

async function gh(path, opts = {}) {
  const { token } = syncConfig();
  const res = await fetch(GH + path, {
    ...opts,
    headers: {
      Authorization: 'Bearer ' + token,
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      ...(opts.body ? { 'Content-Type': 'application/json' } : {}),
    },
    cache: 'no-store',
  });
  if (!res.ok) {
    const msg = res.status === 401 ? 'GitHub rejected the token.'
      : res.status === 403 || res.status === 404 ? 'The GitHub token needs the Gists permission (read and write).'
      : `GitHub error ${res.status}`;
    const e = new Error(msg); e.status = res.status; throw e;
  }
  return res.json();
}

async function findOrCreateGist(local) {
  let { gistId } = syncConfig();
  if (gistId) return gistId;
  for (let page = 1; page <= 5; page++) {
    const list = await gh(`/gists?per_page=100&page=${page}`);
    const hit = list.find(g => g.files && g.files[FILE]);
    if (hit) { ls.set('gistId', hit.id); return hit.id; }
    if (list.length < 100) break;
  }
  const created = await gh('/gists', {
    method: 'POST',
    body: JSON.stringify({ description: 'Specchio progress (Italian accent trainer)', public: false,
      files: { [FILE]: { content: JSON.stringify(local) } } }),
  });
  ls.set('gistId', created.id);
  return created.id;
}

async function pull(id) {
  const g = await gh(`/gists/${id}`);
  const f = g.files?.[FILE];
  if (!f) return null;
  if (f.truncated && f.raw_url) {
    const r = await fetch(f.raw_url, { cache: 'no-store' });
    return r.json();
  }
  try { return JSON.parse(f.content); } catch { return null; }
}

async function push(id, data) {
  await gh(`/gists/${id}`, { method: 'PATCH', body: JSON.stringify({ files: { [FILE]: { content: JSON.stringify(data) } } }) });
}

// Pull, merge, push if anything differs. Returns the merged progress.
export async function syncNow(local) {
  const { token } = syncConfig();
  if (!token) return { progress: local, status: 'off' };
  const id = await findOrCreateGist(local);
  const remote = await pull(id);
  const merged = merge(local, remote);
  if (JSON.stringify(merged) !== JSON.stringify(remote)) await push(id, merged);
  return { progress: merged, status: 'ok' };
}
