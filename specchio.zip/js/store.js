// Local persistence: small JSON in localStorage, audio blobs in IndexedDB.

export const ls = {
  get(key, fallback = null) {
    try {
      const v = localStorage.getItem('specchio:' + key);
      return v == null ? fallback : JSON.parse(v);
    } catch { return fallback; }
  },
  set(key, value) {
    try { localStorage.setItem('specchio:' + key, JSON.stringify(value)); } catch { /* storage full or blocked */ }
  },
  del(key) {
    try { localStorage.removeItem('specchio:' + key); } catch { /* ignore */ }
  },
};

let dbp = null;
function db() {
  if (!dbp) {
    dbp = new Promise((resolve, reject) => {
      const req = indexedDB.open('specchio', 1);
      req.onupgradeneeded = () => req.result.createObjectStore('audio');
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    }).catch(() => null);
  }
  return dbp;
}

function tx(mode, fn) {
  return db().then(d => {
    if (!d) return null;
    return new Promise((resolve) => {
      const t = d.transaction('audio', mode);
      const req = fn(t.objectStore('audio'));
      t.oncomplete = () => resolve(req && req.result);
      t.onerror = () => resolve(null);
      t.onabort = () => resolve(null);
    });
  });
}

// Records: { blob: Blob, historyId: string|null, rev: number, savedAt: number }
export const audioCache = {
  get: key => tx('readonly', s => s.get(key)),
  put: (key, rec) => tx('readwrite', s => s.put(rec, key)),
  del: key => tx('readwrite', s => s.delete(key)),
  clear: () => tx('readwrite', s => s.clear()),
  count: () => tx('readonly', s => s.count()),
};
