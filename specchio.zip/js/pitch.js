// Pitch (YIN) and loudness analysis, pure JS so it runs on the phone.

const HOP = 0.01;       // 10 ms between frames
const WIN = 0.04;       // 40 ms analysis window
const FMIN = 65, FMAX = 420;
const THRESH = 0.15;

function toMono(channels) {
  if (channels.length === 1) return channels[0];
  const n = channels[0].length, out = new Float32Array(n);
  for (const ch of channels) for (let i = 0; i < n; i++) out[i] += ch[i] / channels.length;
  return out;
}

// Downsample by an integer factor with a simple box filter (fine for speech pitch < 500 Hz).
function decimate(x, sr, target = 11025) {
  const f = Math.max(1, Math.floor(sr / target));
  if (f === 1) return { x, sr };
  const n = Math.floor(x.length / f), y = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    let s = 0;
    for (let k = 0; k < f; k++) s += x[i * f + k];
    y[i] = s / f;
  }
  return { x: y, sr: sr / f };
}

function yinFrame(x, start, W, tauMin, tauMax, d) {
  for (let tau = 1; tau <= tauMax; tau++) {
    let s = 0;
    for (let j = 0; j < W; j++) {
      const diff = x[start + j] - x[start + j + tau];
      s += diff * diff;
    }
    d[tau] = s;
  }
  // cumulative mean normalized difference
  let run = 0;
  d[0] = 1;
  for (let tau = 1; tau <= tauMax; tau++) {
    run += d[tau];
    d[tau] = run > 0 ? d[tau] * tau / run : 1;
  }
  let tau = -1;
  for (let t = tauMin; t <= tauMax; t++) {
    if (d[t] < THRESH) {
      while (t + 1 <= tauMax && d[t + 1] < d[t]) t++;
      tau = t;
      break;
    }
  }
  if (tau < 0) return 0;
  // parabolic interpolation
  const a = d[tau - 1], b = d[tau], c = tau + 1 <= tauMax ? d[tau + 1] : b;
  const den = a + c - 2 * b;
  const shift = den !== 0 ? 0.5 * (a - c) / den : 0;
  return tau + Math.max(-1, Math.min(1, shift));
}

function median(arr) {
  const v = arr.filter(Number.isFinite).sort((a, b) => a - b);
  if (!v.length) return NaN;
  const m = v.length >> 1;
  return v.length % 2 ? v[m] : (v[m - 1] + v[m]) / 2;
}

// channels: Float32Array[] (as from AudioBuffer.getChannelData), sr: sample rate.
// Returns { t: normalized time 0..1 over the speech span, st: semitones vs speaker median (NaN unvoiced),
//           env: loudness 0..1, dur: seconds of speech }
export function analyze(channels, sr) {
  const mono = toMono(channels);
  const { x, sr: fs } = decimate(mono, sr);
  const W = Math.round(WIN * fs), hop = Math.round(HOP * fs);
  const tauMin = Math.floor(fs / FMAX), tauMax = Math.ceil(fs / FMIN);
  const frames = Math.max(0, Math.floor((x.length - W - tauMax) / hop));
  const f0 = new Float32Array(frames), rms = new Float32Array(frames);
  const d = new Float32Array(tauMax + 2);
  for (let i = 0; i < frames; i++) {
    const s = i * hop;
    let e = 0;
    for (let j = 0; j < W; j++) e += x[s + j] * x[s + j];
    rms[i] = Math.sqrt(e / W);
  }
  const maxR = rms.reduce((m, v) => Math.max(m, v), 1e-9);
  for (let i = 0; i < frames; i++) {
    if (rms[i] < maxR * 0.06) { f0[i] = 0; continue; }
    const tau = yinFrame(x, i * hop, W, tauMin, tauMax, d);
    f0[i] = tau > 0 ? fs / tau : 0;
  }
  // speech span: first/last frame above 12% of max loudness
  let a = 0, b = frames - 1;
  while (a < frames && rms[a] < maxR * 0.12) a++;
  while (b > a && rms[b] < maxR * 0.12) b--;
  a = Math.max(0, a - 3); b = Math.min(frames - 1, b + 3);
  const n = Math.max(1, b - a + 1);
  let hz = Array.from(f0.slice(a, b + 1), v => (v > 0 ? v : NaN));

  // octave-error correction against the utterance median
  const med0 = median(hz);
  hz = hz.map(v => !Number.isFinite(v) ? v : v > med0 * 1.8 ? v / 2 : v < med0 * 0.55 ? v * 2 : v);
  // 5-point median smoothing within voiced runs
  hz = hz.map((v, i) => {
    if (!Number.isFinite(v)) return v;
    return median(hz.slice(Math.max(0, i - 2), i + 3));
  });
  // drop voiced islands shorter than 4 frames (likely glitches)
  for (let i = 0; i < hz.length;) {
    if (!Number.isFinite(hz[i])) { i++; continue; }
    let j = i;
    while (j < hz.length && Number.isFinite(hz[j])) j++;
    if (j - i < 4) for (let k = i; k < j; k++) hz[k] = NaN;
    i = j;
  }
  const med = median(hz);
  const st = hz.map(v => (Number.isFinite(v) && med > 0 ? 12 * Math.log2(v / med) : NaN));
  const env = Array.from(rms.slice(a, b + 1), v => {
    const db = 20 * Math.log10(v / maxR + 1e-6);
    return Math.max(0, Math.min(1, (db + 40) / 40));
  });
  const t = st.map((_, i) => (n > 1 ? i / (n - 1) : 0));
  return { t, st, env, dur: n * HOP, medianHz: med };
}

export async function analyzeBlob(blob, ctx) {
  const buf = await blob.arrayBuffer();
  const audio = await new Promise((resolve, reject) => {
    // callback form for older Safari
    const p = ctx.decodeAudioData(buf, resolve, reject);
    if (p && p.then) p.then(resolve, reject);
  });
  const chans = [];
  for (let c = 0; c < audio.numberOfChannels; c++) chans.push(audio.getChannelData(c));
  return analyze(chans, audio.sampleRate);
}
