import { SENTENCES, SENTENCE_BY_ID } from './data/sentences.js';
import { GUIDE, GUIDE_BY_ID, GROUPS } from './data/guide.js';
import { schedule, newCard, previewIntervals, formatDelay, dayStart, dayKey, DAY, LEARN_AHEAD } from './srs.js';
import { ls, audioCache } from './store.js';
import * as EL from './eleven.js';
import { progressStore, syncNow, syncConfig } from './progress.js';
import { Recorder, micSupported } from './recorder.js';
import { analyzeBlob } from './pitch.js';
import { drawChart } from './chart.js';
import { diagramFor } from './diagrams.js';

// ───────────────────────── helpers ─────────────────────────
const $ = s => document.querySelector(s);
const main = $('#main');
const player = $('#player');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const ICON = {
  play: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg>',
  rec: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="6"/></svg>',
  stop: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="7" y="7" width="10" height="10" rx="1.5"/></svg>',
  back: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
};
const SECTION = {
  core: 'Core', geminates: 'Double consonants', raddoppiamento: 'Doubling across words', elision: 'Elision and shortening',
  nasals: 'Nasals', stress: 'Stress', vowels: 'Vowels', consonants: 'Consonants', intonation: 'Intonation',
};
const RATING = ['Again', 'Hard', 'Good', 'Easy'];

// ───────────────────────── state ─────────────────────────
let P = progressStore.load();
const ui = {
  view: 'practice', cardId: null, browseId: null, guideId: null,
  filter: 'all', query: '', showMeaning: ls.get('showMeaning', false),
  sessionCount: 0, lastId: null, undo: null, confirmRegen: null, meaningOpen: false,
};
const media = {
  ctx: null, native: new Map(), you: null, recorder: null, recording: false,
  slow: false, status: '', statusErr: false, loadingKey: null,
};
const prefs = {
  get autoplay() { return ls.get('autoplay', true); },
  get playTake() { return ls.get('playTake', true); },
};

function save() { progressStore.save(P); scheduleSync(); }
function cardState(id) { return P.cards[id] || newCard(); }

// ───────────────────────── scheduling queue ─────────────────────────
function extraToday() { return ls.get('extra:' + dayKey(Date.now()), 0); }
function introducedToday() {
  const k = dayKey(Date.now());
  return Object.values(P.cards).filter(c => c.intro && dayKey(c.intro) === k).length;
}
function newQuota() {
  return Math.max(0, (P.settings.newPerDay ?? 10) + extraToday() - introducedToday());
}
function queue(now = Date.now()) {
  const cutoff = dayStart(now) + DAY;
  const learning = [], reviews = [], ahead = [];
  for (const s of SENTENCES) {
    const c = P.cards[s.id];
    if (!c || c.state === 'new') continue;
    if (c.state === 'learning' || c.state === 'relearning') {
      if (c.due <= now) learning.push(s.id); else if (c.due <= now + LEARN_AHEAD) ahead.push(s.id);
    } else if (c.due < cutoff) reviews.push(s.id);
  }
  const byDue = (a, b) => P.cards[a].due - P.cards[b].due;
  learning.sort(byDue); reviews.sort(byDue); ahead.sort(byDue);
  const quota = newQuota();
  const fresh = SENTENCES.filter(s => !P.cards[s.id] || P.cards[s.id].state === 'new').slice(0, quota).map(s => s.id);
  const learningAll = Object.values(P.cards).filter(c => c.state === 'learning' || c.state === 'relearning').length;
  return { learning, reviews, fresh, ahead, counts: { new: fresh.length, learn: learningAll, rev: reviews.length } };
}
function pickNext() {
  const q = queue();
  const avoid = id => id === ui.lastId;
  const first = (arr) => arr.find(id => !avoid(id)) || null;
  let id = first(q.learning);
  if (!id) {
    const preferNew = q.fresh.length && (!q.reviews.length || ui.sessionCount % 4 === 3);
    id = preferNew ? first(q.fresh) : first(q.reviews) || first(q.fresh);
  }
  if (!id) id = first(q.ahead) || q.learning[0] || q.ahead[0] || null;
  return id;
}

// ───────────────────────── audio ─────────────────────────
function ctx() {
  if (!media.ctx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    media.ctx = new AC();
  }
  return media.ctx;
}
function audioKey(text) { const c = EL.config(); return `${c.voice}|${c.model}|${text.trim()}`; }
function revFor(cardId) { return cardId ? (P.cards[cardId]?.audioRev || 0) : 0; }
function memKey(text, cardId) { return audioKey(text) + '#' + revFor(cardId); }

// Find native audio: device cache → ElevenLabs history → (optionally) generate.
const inflight = new Map();
function ensureNative(text, opts = {}) {
  const base = memKey(text, opts.cardId || null);
  if (media.native.has(base)) return Promise.resolve(media.native.get(base));
  const gen = opts.allowGenerate !== false;
  const k = base + (gen ? '|gen' : '|look');
  if (inflight.has(k)) return inflight.get(k);
  // a generating request also answers a lookup; a generating request waits for any lookup first
  if (!gen && inflight.has(base + '|gen')) return inflight.get(base + '|gen');
  const before = gen ? inflight.get(base + '|look') : null;
  const p = Promise.resolve(before ? before.catch(() => null) : null)
    .then(r => r || ensureNativeInner(text, opts))
    .finally(() => inflight.delete(k));
  inflight.set(k, p);
  return p;
}
async function ensureNativeInner(text, { cardId = null, allowGenerate = true } = {}) {
  const mk = memKey(text, cardId);
  if (media.native.has(mk)) return media.native.get(mk);
  const key = audioKey(text), rev = revFor(cardId);
  let blob = null, source = 'device', historyId = null;
  const cached = await audioCache.get(key);
  if (cached && (cached.rev || 0) === rev) { blob = cached.blob; historyId = cached.historyId; }
  else {
    const res = await EL.fetchAudio(text, { allowGenerate });
    if (!res) return null;
    blob = res.blob; historyId = res.historyId; source = res.generated ? 'generated' : 'history';
    await audioCache.put(key, { blob, historyId, rev, savedAt: Date.now() });
  }
  let ana = null;
  try { ana = await analyzeBlob(blob, ctx()); } catch { /* chart unavailable for this clip */ }
  const entry = { url: URL.createObjectURL(blob), ana, source, historyId, cost: EL.creditCost(text) };
  media.native.set(mk, entry);
  return entry;
}

function play(url, onend) {
  if (!url) return;
  player.onended = onend || null;
  player.src = url;
  player.playbackRate = media.slow ? 0.75 : 1;
  player.preservesPitch = true; player.webkitPreservesPitch = true;
  player.play().catch(err => {
    if (err && err.name === 'NotAllowedError') setStatus('Tap Native to play (the browser blocked automatic playback).');
  });
}

// iOS only allows programmatic playback on an element the user has already started once.
let unlocked = false;
function silentUrl() {
  const n = 400, b = new ArrayBuffer(44 + n * 2), v = new DataView(b);
  const w = (o, s) => [...s].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
  w(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); w(8, 'WAVE'); w(12, 'fmt '); v.setUint32(16, 16, true);
  v.setUint16(20, 1, true); v.setUint16(22, 1, true); v.setUint32(24, 8000, true); v.setUint32(28, 16000, true);
  v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, n * 2, true);
  return URL.createObjectURL(new Blob([b], { type: 'audio/wav' }));
}
document.addEventListener('pointerdown', () => {
  if (unlocked) return;
  unlocked = true;
  try { player.src = silentUrl(); player.play().catch(() => {}); } catch { /* ignore */ }
  try { ctx().resume?.(); } catch { /* ignore */ }
}, { capture: true });

function setStatus(text, err = false) {
  media.status = text; media.statusErr = err;
  const el = $('#status');
  if (el) { el.textContent = text; el.classList.toggle('err', err); }
}
function sourceText(e) {
  if (!e) return '';
  return e.source === 'generated' ? `Generated just now · ${e.cost} credits`
    : e.source === 'history' ? 'Downloaded from your ElevenLabs history · no credits'
    : 'Saved on this device';
}

function resetTake() {
  if (media.you?.url) URL.revokeObjectURL(media.you.url);
  media.you = null;
}

// ───────────────────────── toast ─────────────────────────
let toastTimer = null;
function toast(html, ms = 4000) {
  const t = $('#toast');
  t.innerHTML = html; t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, ms);
}

// ───────────────────────── sync ─────────────────────────
let syncTimer = null, syncing = false, syncAgain = false;
function setSync(state, msg) {
  const d = $('#syncDot');
  d.dataset.state = state;
  d.title = msg || { off: 'Sync is off. Add a GitHub token in Settings.', busy: 'Syncing…', ok: 'Synced', error: 'Sync failed' }[state];
  ui.syncMsg = d.title;
  if (ui.view === 'settings') { const s = $('#syncStatus'); if (s) s.textContent = d.title; }
}
function scheduleSync() { clearTimeout(syncTimer); syncTimer = setTimeout(doSync, 2500); }
async function doSync() {
  if (!syncConfig().token) { setSync('off'); return; }
  if (syncing) { syncAgain = true; return; }
  syncing = true; setSync('busy');
  try {
    const { progress } = await syncNow(P);
    P = progress; progressStore.save(P);
    setSync('ok', 'Synced ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    if (ui.view === 'practice') renderCounts();
  } catch (e) {
    setSync('error', 'Sync failed: ' + (e.message || e));
  } finally {
    syncing = false;
    if (syncAgain) { syncAgain = false; scheduleSync(); }
  }
}
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') doSync(); });

// ───────────────────────── routing ─────────────────────────
const VIEWS = ['practice', 'cards', 'sounds', 'progress', 'settings'];
function route() {
  const h = (location.hash || '#practice').slice(1);
  const v = VIEWS.includes(h) ? h : 'practice';
  if (media.recording) stopRecording(true);
  ui.view = v;
  document.querySelectorAll('[data-nav]').forEach(a => {
    if (a.classList.contains('brand')) return;
    a.toggleAttribute('aria-current', a.dataset.nav === v);
    if (a.dataset.nav === v) a.setAttribute('aria-current', 'page');
  });
  render();
}
window.addEventListener('hashchange', route);
function go(view) { if (location.hash === '#' + view) route(); else location.hash = view; }

function render() {
  ui.confirmRegen = null;
  ({ practice: renderPractice, cards: renderCards, sounds: renderSounds, progress: renderProgress, settings: renderSettings })[ui.view]();
  window.scrollTo(0, 0);
}

// ───────────────────────── card component ─────────────────────────
function tagChips(tags) {
  return tags.map(t => {
    const g = GUIDE_BY_ID[t];
    return g ? `<button class="chip" data-action="guide" data-id="${t}">${esc(g.title)}</button>` : '';
  }).join('');
}
function statusBadge(id, now = Date.now()) {
  const c = P.cards[id];
  if (!c || c.state === 'new') return '<span class="badge new">new</span>';
  if (c.state !== 'review') return '<span class="badge learning">learning</span>';
  if (c.due < dayStart(now) + DAY) return '<span class="badge due">due</span>';
  return `<span class="badge">in ${formatDelay(c.due - dayStart(now))}</span>`;
}

function cardHTML(id, mode) {
  const s = SENTENCE_BY_ID[id];
  const nat = media.native.get(memKey(s.it, id));
  const you = media.you?.cardId === id ? media.you : null;
  const rec = media.recording;
  const meaning = ui.showMeaning || ui.meaningOpen;
  const prev = mode === 'review' ? previewIntervals(cardState(id)) : null;
  const regen = ui.confirmRegen === id
    ? `<span class="muted">Generate this sentence again for about ${EL.creditCost(s.it)} credits?</span>
       <button class="btn small" data-action="regen-yes">Regenerate</button><button class="linkish" data-action="regen-no">Cancel</button>`
    : `<button class="linkish" data-action="regen">Audio sounds wrong? Regenerate</button>`;
  return `
  <article class="panel card" aria-label="Practice card">
    <div class="card-head">
      <span class="eyebrow">${esc(SECTION[s.section] || s.section)} · ${s.order + 1} of ${SENTENCES.length}</span>
      ${mode === 'browse' ? statusBadge(id) : ''}
    </div>
    <p class="sentence" lang="it">${esc(s.it)}</p>
    <div>${meaning ? `<div class="meaning">${esc(s.en)}</div>` : `<button class="reveal" data-action="meaning">Show meaning</button>`}</div>
    <div class="listen"><b>Listen for:</b> ${esc(s.note)}</div>
    <div class="tags">${tagChips(s.tags)}</div>
    <div class="controls">
      <button class="btn native-play" data-action="native">${ICON.play}Native</button>
      <button class="btn rec${rec ? ' on' : ''}" data-action="record" ${micSupported() ? '' : 'disabled'}>${rec ? ICON.stop + 'Stop' : ICON.rec + 'Record'}</button>
      <button class="btn" data-action="you" ${you ? '' : 'disabled'}>${ICON.play}You</button>
      <button class="btn" data-action="ab" ${you && nat ? '' : 'disabled'} title="Native, then you">A/B</button>
    </div>
    <div class="level" ${rec ? '' : 'hidden'}><i id="lvl"></i></div>
    <div class="subcontrols">
      <span class="status${media.statusErr ? ' err' : ''}" id="status">${esc(media.status)}</span>
      <label class="check small"><input type="checkbox" id="slow" ${media.slow ? 'checked' : ''}> Slow (0.75×)</label>
    </div>
    <div class="chart-wrap">
      <canvas class="chart" id="chart" aria-label="Pitch overlay: native in grey, you in orange"></canvas>
      <div class="legend"><span><i style="background:var(--native)"></i>Native</span><span><i style="background:var(--you)"></i>You</span><span>Pitch in semitones around each speaker's own average. The strips show loudness: dips are consonants, and double consonants make longer dips.</span></div>
    </div>
    ${mode === 'review' ? `
    <div class="stack" style="gap:6px">
      <div class="rate" role="group" aria-label="How did it go?">
        ${RATING.map((r, i) => `<button class="r${i + 1}" data-action="rate" data-r="${i + 1}"><b>${r}</b><span>${prev[i]}</span></button>`).join('')}
      </div>
      <div class="kbd">Keys: Space native · R record · Y you · A A/B · 1–4 rate</div>
    </div>` : ''}
    <div class="row regen">${regen}</div>
  </article>`;
}

function drawCurrentChart(id) {
  const c = $('#chart');
  if (!c) return;
  const s = SENTENCE_BY_ID[id];
  const nat = media.native.get(memKey(s.it, id));
  const you = media.you?.cardId === id ? media.you : null;
  drawChart(c, nat?.ana || null, you?.ana || null);
}

function currentCardId() { return ui.view === 'practice' ? ui.cardId : ui.browseId; }

function refreshCard() {
  const id = currentCardId();
  const host = $('#cardHost');
  if (!id || !host) return;
  host.innerHTML = cardHTML(id, ui.view === 'practice' ? 'review' : 'browse');
  drawCurrentChart(id);
}

async function loadNative(id, { allowGenerate, autoplay }) {
  const s = SENTENCE_BY_ID[id];
  if (!EL.hasKey()) { setStatus('Add your ElevenLabs API key in Settings to hear the native audio.', true); return null; }
  const mk = memKey(s.it, id);
  if (media.native.has(mk)) {
    const e = media.native.get(mk);
    e.source = 'device';
    setStatus(sourceText(e));
    if (autoplay) play(e.url);
    return e;
  }
  media.loadingKey = mk;
  setStatus(allowGenerate ? 'Getting audio…' : 'Checking for saved audio…');
  try {
    const e = await ensureNative(s.it, { cardId: id, allowGenerate });
    if (media.loadingKey !== mk) return e;
    if (!e) { setStatus(`No audio yet. Tap Native to generate it (about ${EL.creditCost(s.it)} credits).`); return null; }
    if (e.source === 'generated') refreshCredits();
    if (currentCardId() === id) { refreshCard(); setStatus(sourceText(e)); }
    if (autoplay && currentCardId() === id) play(e.url);
    return e;
  } catch (err) {
    if (currentCardId() === id) setStatus(err.message || String(err), true);
    return null;
  }
}

let creditsCache = null;
async function refreshCredits() {
  try { creditsCache = await EL.credits(); } catch { creditsCache = null; }
  const el = $('#credits');
  if (el) el.textContent = creditsCache ? `${creditsCache.left.toLocaleString()} credits left` : 'Could not read credits (the key may lack User read permission).';
}

async function toggleRecord() {
  if (media.recording) return stopRecording();
  const id = currentCardId();
  try {
    media.recorder = new Recorder(level => {
      const l = $('#lvl'); if (l) l.style.width = Math.min(100, level * 140) + '%';
    }, () => stopRecording());
    player.pause();
    await media.recorder.start();
    media.recording = true;
    media.recCard = id;
    setStatus('Recording… tap Stop when you finish.');
    refreshCard();
  } catch (e) {
    media.recording = false;
    setStatus(e && e.name === 'NotAllowedError'
      ? 'Microphone access is blocked. Allow it for this site in your browser settings, then try again.'
      : 'Could not start the microphone: ' + (e.message || e), true);
  }
}

async function stopRecording(discard = false) {
  if (!media.recording) return;
  media.recording = false;
  const blob = await media.recorder.stop();
  const id = media.recCard;
  if (discard || !blob || !blob.size) return;
  resetTake();
  let ana = null;
  try { ana = await analyzeBlob(blob, ctx()); } catch { /* ignore */ }
  media.you = { cardId: id, url: URL.createObjectURL(blob), ana };
  if (currentCardId() === id) {
    refreshCard();
    setStatus(ana ? 'Recorded. Compare the lines, or play A/B.' : 'Recorded (pitch could not be read from this take).');
    if (prefs.playTake) play(media.you.url);
  }
}

async function playNativeFor(id) {
  const e = await loadNative(id, { allowGenerate: true, autoplay: false });
  if (e) play(e.url);
}

function ab(id) {
  const s = SENTENCE_BY_ID[id];
  const nat = media.native.get(memKey(s.it, id));
  if (!nat || !media.you) return;
  play(nat.url, () => setTimeout(() => play(media.you.url), 350));
}

async function regenerate(id) {
  const s = SENTENCE_BY_ID[id];
  ui.confirmRegen = null;
  const key = audioKey(s.it);
  const cached = await audioCache.get(key);
  const mk = memKey(s.it, id);
  const old = media.native.get(mk);
  const hid = old?.historyId || cached?.historyId || EL.knownInHistory(s.it)?.id;
  setStatus('Removing the old audio…');
  if (hid) await EL.deleteHistoryItem(hid);
  await audioCache.del(key);
  media.native.delete(mk);
  const c = { ...cardState(id) };
  c.audioRev = (c.audioRev || 0) + 1;
  c.t = Date.now();
  P.cards[id] = c;
  save();
  refreshCard();
  await loadNative(id, { allowGenerate: true, autoplay: true });
}

function rate(r) {
  const id = ui.cardId;
  if (!id) return;
  const now = Date.now();
  const before = P.cards[id] ? { ...P.cards[id] } : null;
  const next = schedule(cardState(id), r, now);
  next.t = now;
  P.cards[id] = next;
  const entry = { id: uid(), c: id, r, ts: now, s: before?.state || 'new' };
  P.log.push(entry);
  ui.undo = { id, before, logId: entry.id };
  ui.sessionCount++;
  ui.lastId = id;
  save();
  const when = next.state === 'review' ? formatDelay(next.due - dayStart(now)) : formatDelay(next.due - now);
  toast(`${RATING[r - 1]} · back in ${when} <button data-action="undo">Undo</button>`, 6000);
  advance();
}

function undo() {
  const u = ui.undo;
  if (!u) return;
  const now = Date.now();
  P.cards[u.id] = { ...(u.before || newCard()), t: now };
  const e = P.log.find(x => x.id === u.logId);
  if (e) e.undone = true;
  ui.undo = null;
  ui.lastId = null;
  ui.sessionCount = Math.max(0, ui.sessionCount - 1);
  save();
  $('#toast').hidden = true;
  if (ui.view !== 'practice') { go('practice'); }
  ui.cardId = u.id;
  showPracticeCard();
}

function advance() {
  if (media.recording) stopRecording(true);
  resetTake();
  ui.meaningOpen = false;
  media.status = ''; media.statusErr = false;
  ui.cardId = pickNext();
  showPracticeCard();
}

// ───────────────────────── views ─────────────────────────
function renderCounts() {
  const el = $('#counts');
  if (!el) return;
  const { counts } = queue();
  el.innerHTML = `
    <span class="count new"><b>${counts.new}</b>new</span>
    <span class="count learn"><b>${counts.learn}</b>learning</span>
    <span class="count rev"><b>${counts.rev}</b>to review</span>`;
}

function renderPractice() {
  main.innerHTML = `
    <div class="stack">
      <div class="counts" id="counts"></div>
      ${EL.hasKey() ? '' : `<div class="panel setup stack" style="gap:8px">
        <h3>Connect ElevenLabs to hear the native audio</h3>
        <p class="muted small" style="margin:0">Paste your API key in Settings. Each sentence is generated the first time you see it, then reused on all your devices.</p>
        <div><a class="btn small primary" href="#settings">Open Settings</a></div></div>`}
      <div id="cardHost"></div>
    </div>`;
  if (!ui.cardId || !SENTENCE_BY_ID[ui.cardId]) ui.cardId = pickNext();
  showPracticeCard();
}

function showPracticeCard() {
  renderCounts();
  const host = $('#cardHost');
  if (!host) return;
  if (!ui.cardId) {
    const q = queue();
    const next = Object.values(P.cards).filter(c => c.state === 'review').sort((a, b) => a.due - b.due)[0];
    const unseen = SENTENCES.filter(s => !P.cards[s.id] || P.cards[s.id].state === 'new').length;
    host.innerHTML = `
      <div class="panel done">
        <span class="eyebrow">Finito per oggi</span>
        <h2>You're done for today</h2>
        <p class="muted" style="margin:0">${next ? `Next review in ${formatDelay(Math.max(0, next.due - Date.now()))}.` : ''} ${unseen} sentences not started yet.</p>
        <div class="row" style="justify-content:center">
          ${unseen ? '<button class="btn primary" data-action="more-new">Add 5 new cards today</button>' : ''}
          <a class="btn" href="#cards">Browse all cards</a>
        </div>
      </div>`;
    return;
  }
  host.innerHTML = cardHTML(ui.cardId, 'review');
  drawCurrentChart(ui.cardId);
  if (EL.hasKey()) loadNative(ui.cardId, { allowGenerate: true, autoplay: prefs.autoplay && unlocked });
  else setStatus('Add your ElevenLabs API key in Settings to hear the native audio.', true);
}

function renderCards() {
  if (ui.browseId) {
    main.innerHTML = `
      <div class="stack">
        <div><button class="btn small ghost" data-action="list-back">${ICON.back}All cards</button></div>
        <div id="cardHost"></div>
        <p class="muted small" style="margin:0">Free practice: nothing here changes your review schedule.</p>
      </div>`;
    refreshCard();
    if (EL.hasKey()) loadNative(ui.browseId, { allowGenerate: false, autoplay: false });
    else setStatus('Add your ElevenLabs API key in Settings to hear the native audio.', true);
    return;
  }
  const now = Date.now();
  const F = [['all', 'All'], ['new', 'Not started'], ['learning', 'Learning'], ['due', 'Due'], ['seen', 'Seen']];
  main.innerHTML = `
    <div class="stack">
      <h2>All cards</h2>
      <input class="search" id="q" type="search" placeholder="Search Italian or English" value="${esc(ui.query)}" aria-label="Search cards">
      <div class="filters">${F.map(([k, l]) => `<button class="chip" data-action="filter" data-f="${k}" aria-pressed="${ui.filter === k}">${l}</button>`).join('')}</div>
      <div class="list" id="list"></div>
    </div>`;
  const listEl = $('#list');
  const draw = () => {
    const q = ui.query.trim().toLowerCase();
    const rows = SENTENCES.filter(s => {
      const c = P.cards[s.id];
      const st = !c || c.state === 'new' ? 'new' : c.state === 'review' ? (c.due < dayStart(now) + DAY ? 'due' : 'seen') : 'learning';
      if (ui.filter === 'new' && st !== 'new') return false;
      if (ui.filter === 'learning' && st !== 'learning') return false;
      if (ui.filter === 'due' && st !== 'due') return false;
      if (ui.filter === 'seen' && st === 'new') return false;
      return !q || s.it.toLowerCase().includes(q) || s.en.toLowerCase().includes(q);
    });
    listEl.innerHTML = rows.length ? rows.map(s => `
      <button data-action="open-card" data-id="${s.id}">
        <span class="it" lang="it">${esc(s.it)}</span>${statusBadge(s.id, now)}
        <span class="en">${esc(s.en)}</span>
      </button>`).join('') : '<p class="muted" style="padding:14px;margin:0">No cards match.</p>';
  };
  draw();
  $('#q').addEventListener('input', e => { ui.query = e.target.value; draw(); });
}

function renderSounds() {
  if (ui.guideId && GUIDE_BY_ID[ui.guideId]) {
    const g = GUIDE_BY_ID[ui.guideId];
    const cards = SENTENCES.filter(s => s.tags.includes(g.id));
    const group = GROUPS.find(x => x.id === g.group)?.title || '';
    main.innerHTML = `
      <div class="stack">
        <div><button class="btn small ghost" data-action="guide-back">${ICON.back}All sounds</button></div>
        <article class="panel sound-detail">
          <div class="sound-top">
            <div class="stack" style="gap:8px">
              <span class="eyebrow">${esc(group)}</span>
              ${g.ipa ? `<div class="sym-big" lang="it">${esc(g.ipa)}</div>` : ''}
              <h2>${esc(g.title)}</h2>
              ${g.spelling ? `<div class="muted small">Spelled: <span style="font-family:var(--font-it)">${esc(g.spelling)}</span></div>` : ''}
            </div>
            <div>${diagramFor(g)}</div>
          </div>
          <div class="howto"><h3>How to make it</h3><p>${esc(g.mouth)}</p></div>
          ${g.trap ? `<div class="howto trap"><h3>Common mistake for English speakers</h3><p>${esc(g.trap)}</p></div>` : ''}
          ${g.more ? `<div class="howto"><h3>Good to know</h3><p>${esc(g.more)}</p></div>` : ''}
          ${g.examples.length ? `<div class="stack" style="gap:8px"><h3>Hear it</h3>
            <div class="tags">${g.examples.map(w => `<button class="chip ipa" data-action="say" data-text="${esc(w)}">${ICON.play.replace('<svg', '<svg width="12" height="12" fill="currentColor" style="margin-right:4px"')}${esc(w)}</button>`).join('')}</div>
            <span class="muted small">Each word costs a few credits the first time, then it's saved.</span></div>` : ''}
        </article>
        <div class="stack" style="gap:8px">
          <h3>${cards.length} cards practise this</h3>
          <div class="list">${cards.map(s => `<button data-action="open-card" data-id="${s.id}"><span class="it" lang="it">${esc(s.it)}</span>${statusBadge(s.id)}<span class="en">${esc(s.en)}</span></button>`).join('')}</div>
        </div>
      </div>`;
    return;
  }
  main.innerHTML = `
    <div class="stack">
      <h2>The sounds of Italian</h2>
      <p class="muted" style="margin:0;max-width:62ch">Every sound and connected-speech habit the cards practise. Tap one for how to make it, the usual English-speaker mistake, and the cards that train it.</p>
      <div class="groups">
        ${GROUPS.map(gr => `
          <section class="stack" style="gap:8px">
            <h3>${esc(gr.title)}</h3>
            <div class="sound-grid">
              ${GUIDE.filter(g => g.group === gr.id).map(g => `
                <button data-action="guide" data-id="${g.id}">
                  ${g.ipa ? `<span class="sym" lang="it">${esc(g.ipa)}</span>` : ''}
                  <span class="nm">${esc(g.title)}</span>
                </button>`).join('')}
            </div>
          </section>`).join('')}
      </div>
    </div>`;
}

function renderProgress() {
  const now = Date.now();
  const log = P.log.filter(e => !e.undone);
  const seen = SENTENCES.filter(s => P.cards[s.id] && P.cards[s.id].state !== 'new').length;
  const q = queue(now);
  const week = log.filter(e => e.ts > now - 7 * DAY).length;
  const revs = log.filter(e => e.s === 'review' && e.ts > now - 30 * DAY);
  const retention = revs.length ? Math.round(100 * revs.filter(e => e.r > 1).length / revs.length) + '%' : '—';

  // weak spots: share of Again/Hard per tag over the last 60 days
  const per = {};
  for (const e of log) {
    if (e.ts < now - 60 * DAY) continue;
    const s = SENTENCE_BY_ID[e.c];
    if (!s) continue;
    for (const t of s.tags) {
      per[t] = per[t] || { n: 0, bad: 0 };
      per[t].n++; if (e.r <= 2) per[t].bad++;
    }
  }
  const weak = Object.entries(per).filter(([, v]) => v.n >= 3)
    .map(([t, v]) => ({ t, n: v.n, pct: v.bad / v.n })).sort((a, b) => b.pct - a.pct || b.n - a.n).slice(0, 14);

  // 7-day forecast
  const start = dayStart(now);
  const days = Array.from({ length: 7 }, (_, i) => {
    const a = start + i * DAY, b = a + DAY;
    const n = Object.values(P.cards).filter(c => c.state === 'review' && (i === 0 ? c.due < b : c.due >= a && c.due < b)).length;
    const label = i === 0 ? 'today' : new Date(a).toLocaleDateString([], { weekday: 'short' });
    return { n, label };
  });
  const maxN = Math.max(1, ...days.map(d => d.n));

  main.innerHTML = `
    <div class="stack" style="gap:20px">
      <h2>Progress</h2>
      <div class="tiles">
        <div class="tile"><div class="v">${seen}<span class="muted" style="font-size:15px"> / ${SENTENCES.length}</span></div><div class="k">sentences started</div></div>
        <div class="tile"><div class="v">${q.counts.rev + q.counts.learn}</div><div class="k">due now</div></div>
        <div class="tile"><div class="v">${week}</div><div class="k">ratings this week</div></div>
        <div class="tile"><div class="v">${retention}</div><div class="k">reviews not rated Again (30 days)</div></div>
      </div>
      <section class="panel stack">
        <div><h3>Weak spots</h3><p class="muted small" style="margin:4px 0 0">How often you rate cards with each feature Again or Hard (last 60 days). Tap one to open its guide.</p></div>
        ${weak.length ? `<div class="weak">${weak.map(w => `
          <button data-action="guide" data-id="${w.t}">
            <span>${esc(GUIDE_BY_ID[w.t]?.title || w.t)} <span class="muted small">· ${w.n}</span></span>
            <span class="bar"><i style="width:${Math.round(w.pct * 100)}%"></i></span>
            <span class="pct">${Math.round(w.pct * 100)}%</span>
          </button>`).join('')}</div>`
        : '<p class="muted" style="margin:0">This fills in after a few days of practice. Each feature needs at least 3 ratings.</p>'}
      </section>
      <section class="panel stack">
        <h3>Reviews coming up</h3>
        <div class="forecast">${days.map(d => `<div><span>${d.n}</span><i style="height:${Math.round(70 * d.n / maxN)}%"></i><span>${d.label}</span></div>`).join('')}</div>
      </section>
    </div>`;
}

function renderSettings() {
  const c = EL.config(), s = syncConfig();
  main.innerHTML = `
    <div class="stack" style="gap:20px">
      <h2>Settings</h2>
      <section class="panel stack">
        <h3>ElevenLabs</h3>
        <div class="field"><label for="elKey">API key</label>
          <input id="elKey" type="password" autocomplete="off" spellcheck="false" value="${esc(c.key)}" placeholder="sk_…">
          <span class="hint">Stored only in this browser. Create it at elevenlabs.io → Developers → API keys, with access to Text to Speech, Speech History (read and write) and User (read). Setting a credit limit on the key is a good safety net.</span></div>
        <div class="field"><label for="elVoice">Voice ID</label><input id="elVoice" type="text" spellcheck="false" value="${esc(c.voice)}"></div>
        <div class="field"><label for="elModel">Model</label><input id="elModel" type="text" spellcheck="false" value="${esc(c.model)}"><span class="hint">Changing the voice or model creates new audio for every sentence.</span></div>
        <div class="row"><button class="btn small" data-action="credits">Check credits</button><span id="credits" class="muted small">${creditsCache ? creditsCache.left.toLocaleString() + ' credits left' : ''}</span></div>
      </section>
      <section class="panel stack">
        <h3>Sync between devices</h3>
        <div class="field"><label for="ghToken">GitHub token</label>
          <input id="ghToken" type="password" autocomplete="off" spellcheck="false" value="${esc(s.token)}" placeholder="github_pat_…">
          <span class="hint">A fine-grained token with only the Gists permission (read and write). Your progress is stored in one private gist. Use the same token on each device.</span></div>
        <div class="row"><button class="btn small" data-action="sync">Sync now</button><span id="syncStatus" class="muted small">${esc(ui.syncMsg || '')}</span></div>
      </section>
      <section class="panel stack">
        <h3>Practice</h3>
        <div class="field"><label for="newPerDay">New cards per day</label><input id="newPerDay" type="number" min="0" max="50" inputmode="numeric" value="${P.settings.newPerDay ?? 10}" style="max-width:120px"></div>
        <label class="check"><input type="checkbox" id="autoplay" ${prefs.autoplay ? 'checked' : ''}> Play the native audio when a card opens</label>
        <label class="check"><input type="checkbox" id="playTake" ${prefs.playTake ? 'checked' : ''}> Play my recording right after I stop</label>
        <label class="check"><input type="checkbox" id="showMeaning" ${ui.showMeaning ? 'checked' : ''}> Always show the English meaning</label>
      </section>
      <section class="panel stack">
        <h3>This device</h3>
        <p class="muted small" style="margin:0">Downloaded audio is kept on this device so it plays instantly. Clearing it costs nothing: it downloads again from your ElevenLabs history.</p>
        <div class="row"><button class="btn small" data-action="clear-audio">Clear downloaded audio</button><span id="cacheInfo" class="muted small"></span></div>
        <p class="muted small" style="margin:0">No sound on iPhone? Check the volume, and that Bluetooth isn't routing audio elsewhere. Recordings are never stored: each take disappears when you move to the next card.</p>
      </section>
    </div>`;
  audioCache.count().then(n => { const el = $('#cacheInfo'); if (el && n != null) el.textContent = `${n} clips saved`; });
  const bindText = (id, key, after) => $('#' + id).addEventListener('change', e => { ls.set(key, e.target.value.trim()); after?.(); });
  bindText('elKey', 'elKey', () => { media.native.clear(); refreshCredits(); });
  bindText('elVoice', 'elVoice', () => media.native.clear());
  bindText('elModel', 'elModel', () => media.native.clear());
  bindText('ghToken', 'ghToken', () => { ls.del('gistId'); doSync(); });
  $('#newPerDay').addEventListener('change', e => {
    const v = Math.max(0, Math.min(50, parseInt(e.target.value, 10) || 0));
    P.settings = { ...P.settings, newPerDay: v, t: Date.now() };
    save();
  });
  $('#autoplay').addEventListener('change', e => ls.set('autoplay', e.target.checked));
  $('#playTake').addEventListener('change', e => ls.set('playTake', e.target.checked));
  $('#showMeaning').addEventListener('change', e => { ui.showMeaning = e.target.checked; ls.set('showMeaning', e.target.checked); });
}

// ───────────────────────── events ─────────────────────────
document.addEventListener('click', async e => {
  const nav = e.target.closest('[data-nav]');
  if (nav && nav.dataset.nav === ui.view) {
    // tapping the current tab returns to its top level
    if (ui.view === 'cards') ui.browseId = null;
    if (ui.view === 'sounds') ui.guideId = null;
    if (location.hash === '#' + ui.view || (!location.hash && ui.view === 'practice')) { e.preventDefault(); render(); }
  }
  const el = e.target.closest('[data-action]');
  if (!el) return;
  const a = el.dataset.action;
  const id = currentCardId();
  switch (a) {
    case 'native': if (id) playNativeFor(id); break;
    case 'record': toggleRecord(); break;
    case 'you': if (media.you) play(media.you.url); break;
    case 'ab': if (id) ab(id); break;
    case 'rate': rate(+el.dataset.r); break;
    case 'undo': undo(); break;
    case 'meaning': ui.meaningOpen = true; refreshCard(); break;
    case 'regen': ui.confirmRegen = id; refreshCard(); break;
    case 'regen-no': ui.confirmRegen = null; refreshCard(); break;
    case 'regen-yes': if (id) regenerate(id); break;
    case 'more-new': ls.set('extra:' + dayKey(Date.now()), extraToday() + 5); ui.cardId = pickNext(); showPracticeCard(); break;
    case 'guide': ui.guideId = el.dataset.id; if (ui.view !== 'sounds') go('sounds'); else renderSounds(); window.scrollTo(0, 0); break;
    case 'guide-back': ui.guideId = null; renderSounds(); break;
    case 'open-card': if (media.recording) stopRecording(true); resetTake(); ui.meaningOpen = false; media.status = ''; media.statusErr = false; ui.browseId = el.dataset.id; if (ui.view !== 'cards') go('cards'); else renderCards(); window.scrollTo(0, 0); break;
    case 'list-back': if (media.recording) stopRecording(true); resetTake(); ui.browseId = null; renderCards(); break;
    case 'filter': ui.filter = el.dataset.f; renderCards(); break;
    case 'say': {
      if (!EL.hasKey()) { toast('Add your ElevenLabs API key in Settings first.'); break; }
      const text = el.dataset.text;
      try {
        const en = await ensureNative(text, { allowGenerate: true });
        if (en) { play(en.url); if (en.source === 'generated') toast(`Generated “${esc(text)}” · ${en.cost} credits`); }
      } catch (err) { toast(esc(err.message || err)); }
      break;
    }
    case 'sync': doSync(); break;
    case 'credits': $('#credits').textContent = 'Checking…'; refreshCredits(); break;
    case 'clear-audio': await audioCache.clear(); media.native.clear(); toast('Downloaded audio cleared'); renderSettings(); break;
  }
});

document.addEventListener('change', e => {
  if (e.target.id === 'slow') {
    media.slow = e.target.checked;
    if (!player.paused) player.playbackRate = media.slow ? 0.75 : 1;
  }
});

document.addEventListener('keydown', e => {
  if (e.target.closest('input, textarea, select') || e.metaKey || e.ctrlKey || e.altKey) return;
  const id = currentCardId();
  if (!id || !['practice', 'cards'].includes(ui.view)) return;
  const k = e.key.toLowerCase();
  if (k === ' ') { e.preventDefault(); playNativeFor(id); }
  else if (k === 'r') toggleRecord();
  else if (k === 'y' && media.you) play(media.you.url);
  else if (k === 'a') ab(id);
  else if (ui.view === 'practice' && ['1', '2', '3', '4'].includes(k)) rate(+k);
});

let resizeT = null;
window.addEventListener('resize', () => {
  clearTimeout(resizeT);
  resizeT = setTimeout(() => { const id = currentCardId(); if (id) drawCurrentChart(id); }, 120);
});
window.matchMedia?.('(prefers-color-scheme: dark)').addEventListener?.('change', () => { const id = currentCardId(); if (id) drawCurrentChart(id); });

// ───────────────────────── start ─────────────────────────
route();
doSync();
if (EL.hasKey()) EL.refreshHistory().catch(() => {});
