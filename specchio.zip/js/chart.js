// Draws the pitch overlay (semitones vs normalized time) and two loudness strips.

function css(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || '#888';
}

export function drawChart(canvas, native, you) {
  const dpr = window.devicePixelRatio || 1;
  const w = canvas.clientWidth, h = canvas.clientHeight;
  if (!w || !h) return;
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  const g = canvas.getContext('2d');
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.clearRect(0, 0, w, h);

  const strip = 16, gap = 6;
  const padL = 30, padR = 8, padT = 10;
  const ph = h - padT - (strip * 2 + gap * 3) - 8; // pitch area height
  const range = 9; // ±9 semitones visible
  const X = t => padL + t * (w - padL - padR);
  const Y = st => padT + ph / 2 - (Math.max(-range, Math.min(range, st)) / range) * (ph / 2);

  const grid = css('--line'), muted = css('--muted');
  g.font = '11px "IBM Plex Sans", system-ui, sans-serif';
  g.textAlign = 'right';
  g.textBaseline = 'middle';
  for (const st of [-6, 0, 6]) {
    g.strokeStyle = grid;
    g.lineWidth = st === 0 ? 1.2 : 1;
    g.setLineDash(st === 0 ? [] : [3, 4]);
    g.beginPath(); g.moveTo(padL, Y(st)); g.lineTo(w - padR, Y(st)); g.stroke();
    g.fillStyle = muted;
    g.fillText(st > 0 ? '+' + st : String(st), padL - 6, Y(st));
  }
  g.setLineDash([]);

  const line = (a, color, width) => {
    if (!a) return;
    g.strokeStyle = color; g.lineWidth = width; g.lineJoin = 'round'; g.lineCap = 'round';
    let on = false;
    g.beginPath();
    for (let i = 0; i < a.st.length; i++) {
      const v = a.st[i];
      if (!Number.isFinite(v)) { on = false; continue; }
      const px = X(a.t[i]), py = Y(v);
      if (!on) { g.moveTo(px, py); on = true; } else g.lineTo(px, py);
    }
    g.stroke();
  };
  line(native, css('--native'), 4);
  line(you, css('--you'), 2.5);

  // loudness strips: gaps show consonant closures, so double consonants appear as longer gaps
  const stripAt = (a, top, color, label) => {
    g.fillStyle = css('--surface-2');
    g.fillRect(padL, top, w - padL - padR, strip);
    g.fillStyle = muted; g.textAlign = 'right';
    g.fillText(label, padL - 6, top + strip / 2);
    if (!a) return;
    g.fillStyle = color;
    g.beginPath();
    g.moveTo(X(0), top + strip);
    for (let i = 0; i < a.env.length; i++) g.lineTo(X(a.t[i]), top + strip - a.env[i] * strip);
    g.lineTo(X(1), top + strip);
    g.closePath();
    g.fill();
  };
  const s1 = padT + ph + gap * 2;
  stripAt(native, s1, css('--native'), 'N');
  stripAt(you, s1 + strip + gap, css('--you'), 'Y');

  if (!native && !you) {
    g.fillStyle = muted; g.textAlign = 'center';
    g.fillText('Play the native audio and record yourself to see the melody', (padL + w) / 2, padT + ph / 2 - 14);
  }
}
