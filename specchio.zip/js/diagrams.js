// Schematic diagrams for the sound guide: a vowel chart and a side view of the mouth.

const VOWELS = {
  i: [52, 26], e: [68, 66], 'ɛ': [86, 106], a: [138, 146], 'ɔ': [196, 106], o: [198, 66], u: [200, 26],
};

export function vowelChart(target) {
  const dots = Object.entries(VOWELS).map(([v, [x, y]]) => {
    const on = v === target;
    return `<g class="${on ? 'vc-on' : 'vc-off'}">
      <circle cx="${x}" cy="${y}" r="${on ? 13 : 9}"/>
      <text x="${x}" y="${y + 5}" text-anchor="middle">${v}</text></g>`;
  }).join('');
  return `<svg class="diagram" viewBox="0 0 250 182" role="img" aria-label="Vowel chart with ${target} highlighted">
    <path class="vc-frame" d="M40 26 L212 26 L212 146 L104 146 Z"/>
    <path class="vc-grid" d="M56 66 L212 66 M80 106 L212 106 M126 26 L158 146"/>
    ${dots}
    <text class="vc-lab" x="40" y="14">front</text>
    <text class="vc-lab" x="212" y="14" text-anchor="end">back</text>
    <text class="vc-lab" x="6" y="30">close</text>
    <text class="vc-lab" x="6" y="150">open</text>
    <text class="vc-lab" x="212" y="172" text-anchor="end">o, ɔ, u: lips rounded</text>
  </svg>`;
}

const PLACES = {
  bilabial:     { at: [27, 99],  label: 'both lips',               tip: [54, 108], hump: [110, 90] },
  labiodental:  { at: [38, 100], label: 'lower lip on upper teeth', tip: [54, 108], hump: [110, 90] },
  dental:       { at: [47, 92],  label: 'back of the upper teeth',  tip: [49, 94],  hump: [110, 92] },
  alveolar:     { at: [60, 71],  label: 'gum ridge',                tip: [60, 74],  hump: [112, 94] },
  postalveolar: { at: [74, 61],  label: 'just behind the gum ridge', tip: [62, 80], hump: [112, 90], blade: [76, 64] },
  palatal:      { at: [108, 54], label: 'hard palate',              tip: [53, 108], hump: [108, 57] },
  velar:        { at: [152, 59], label: 'soft palate',              tip: [54, 108], hump: [150, 62] },
};

function tonguePath({ tip: [tx, ty], hump: [hx, hy], blade }) {
  const toHump = blade
    ? `C ${tx + 4} ${ty - 10} ${blade[0] - 8} ${blade[1]} ${blade[0]} ${blade[1]} C ${blade[0] + 14} ${blade[1]} ${hx - 26} ${hy} ${hx} ${hy}`
    : `C ${tx + 10} ${ty - 10} ${hx - 34} ${hy} ${hx} ${hy}`;
  return `M ${tx} ${ty} ${toHump} C ${hx + 30} ${hy} 182 ${hy + 14} 186 150 L 188 190 L 120 190 C 90 172 66 150 56 128 C 52 120 ${tx - 4} ${ty + 6} ${tx} ${ty} Z`;
}

export function mouthDiagram(place) {
  const P = PLACES[place] || PLACES.alveolar;
  const [x, y] = P.at;
  return `<figure style="margin:0"><svg class="diagram" viewBox="0 0 240 196" role="img" aria-label="Side view of the mouth, contact at the ${P.label}">
    <path class="m-nasal" d="M58 50 C100 40 160 40 196 52"/>
    <path class="m-head" d="M16 30 C20 52 18 66 24 78 C30 86 32 90 30 96 C27 100 24 104 30 108 C36 112 32 120 30 128 C30 150 40 162 70 172 C100 182 140 184 178 186"/>
    <path class="m-palate" d="M46 82 C50 74 54 70 62 68 C70 66 74 60 84 56 C100 50 124 50 140 52 C156 54 170 62 180 74 C184 80 186 86 184 92"/>
    <path class="m-teeth" d="M40 82 L48 82 L47 96 L42 97 Z M41 104 L47 103 L48 116 L40 116 Z"/>
    <path class="m-wall" d="M198 52 C202 80 204 120 206 190"/>
    <path class="m-tongue" d="${tonguePath(P)}"/>
    <circle class="m-hit" cx="${x}" cy="${y}" r="7"/>
  </svg><figcaption class="muted small">Side view, facing left. Contact: <b style="color:var(--ink)">${P.label}</b></figcaption></figure>`;
}

export function diagramFor(entry) {
  if (!entry.diagram) return '';
  return entry.diagram.type === 'vowel' ? vowelChart(entry.diagram.v) : mouthDiagram(entry.diagram.place);
}
