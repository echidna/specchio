// ElevenLabs: generate speech, and reuse anything already in your ElevenLabs history
// so a sentence generated on one device is never paid for again on another.

import { ls } from './store.js';

const API = 'https://api.elevenlabs.io/v1';
export const DEFAULT_VOICE = '13Cuh3NuYvWOVQtLbRN8';
export const DEFAULT_MODEL = 'eleven_v4';

export function config() {
  return {
    key: ls.get('elKey', ''),
    voice: ls.get('elVoice', DEFAULT_VOICE) || DEFAULT_VOICE,
    model: ls.get('elModel', DEFAULT_MODEL) || DEFAULT_MODEL,
  };
}
export const hasKey = () => !!config().key;

export class ElevenError extends Error {
  constructor(message, status) { super(message); this.status = status; }
}

async function call(path, opts = {}) {
  const { key } = config();
  if (!key) throw new ElevenError('Add your ElevenLabs API key in Settings.', 0);
  let res;
  try {
    res = await fetch(API + path, {
      ...opts,
      headers: { 'xi-api-key': key, ...(opts.headers || {}) },
    });
  } catch {
    throw new ElevenError('Could not reach ElevenLabs. Check your connection.', 0);
  }
  if (!res.ok) {
    let detail = '';
    try {
      const j = await res.json();
      detail = j?.detail?.message || j?.detail?.status || (typeof j?.detail === 'string' ? j.detail : '') || '';
    } catch { /* not json */ }
    const msg = res.status === 401 ? 'ElevenLabs rejected the API key, or the key lacks a permission this needs.'
      : res.status === 429 ? 'ElevenLabs is rate-limiting requests. Wait a moment and try again.'
      : detail.includes('quota') || detail.includes('credits') ? 'Not enough ElevenLabs credits left.'
      : `ElevenLabs error ${res.status}${detail ? ': ' + detail : ''}`;
    throw new ElevenError(msg, res.status);
  }
  return res;
}

export const creditCost = text => text.trim().length;

// ── history index: text → newest history item for this voice ──
let index = null;      // Map<text, {id, date}>
let indexAt = 0;

export async function refreshHistory(force = false) {
  if (!force && index && Date.now() - indexAt < 60_000) return index;
  const { voice } = config();
  const map = new Map();
  let after = null;
  for (let page = 0; page < 20; page++) {
    const q = new URLSearchParams({ page_size: '1000', voice_id: voice });
    if (after) q.set('start_after_history_item_id', after);
    const j = await (await call('/history?' + q)).json();
    for (const h of j.history || []) {
      if (h.voice_id && h.voice_id !== voice) continue;
      const t = (h.text || '').trim();
      const prev = map.get(t);
      if (!prev || (h.date_unix || 0) > prev.date) map.set(t, { id: h.history_item_id, date: h.date_unix || 0 });
    }
    if (!j.has_more) break;
    after = j.last_history_item_id;
  }
  index = map;
  indexAt = Date.now();
  return index;
}

export function knownInHistory(text) {
  return index ? index.get(text.trim()) || null : null;
}

async function historyAudio(id) {
  const res = await call(`/history/${encodeURIComponent(id)}/audio`);
  return res.blob();
}

export async function deleteHistoryItem(id) {
  try { await call(`/history/${encodeURIComponent(id)}`, { method: 'DELETE' }); } catch { /* best effort */ }
  if (index) for (const [t, v] of index) if (v.id === id) index.delete(t);
}

async function generate(text) {
  const { voice, model } = config();
  const res = await call(`/text-to-speech/${encodeURIComponent(voice)}?output_format=mp3_44100_128`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'audio/mpeg' },
    body: JSON.stringify({ text: text.trim(), model_id: model }),
  });
  const historyId = res.headers.get('history-item-id');
  const blob = await res.blob();
  return { blob, historyId };
}

// Find audio for text: history first (free), otherwise generate (costs credits).
// Returns { blob, historyId, generated: boolean }
export async function fetchAudio(text, { allowGenerate = true } = {}) {
  await refreshHistory().catch(() => null);
  let hit = knownInHistory(text);
  if (hit) {
    try { return { blob: await historyAudio(hit.id), historyId: hit.id, generated: false }; }
    catch { /* deleted elsewhere — fall through */ }
  }
  if (!allowGenerate) return null;
  // one forced refresh right before paying, in case another device just generated it
  await refreshHistory(true).catch(() => null);
  hit = knownInHistory(text);
  if (hit) {
    try { return { blob: await historyAudio(hit.id), historyId: hit.id, generated: false }; }
    catch { /* fall through */ }
  }
  const g = await generate(text);
  if (!g.historyId) {
    // the header may not be readable from a browser; look the new item up instead
    await refreshHistory(true).catch(() => null);
    g.historyId = knownInHistory(text)?.id || null;
  } else if (index) {
    index.set(text.trim(), { id: g.historyId, date: Math.floor(Date.now() / 1000) });
  }
  return { ...g, generated: true };
}

export async function credits() {
  const j = await (await call('/user/subscription')).json();
  if (typeof j.character_limit !== 'number') return null;
  return { used: j.character_count, limit: j.character_limit, left: j.character_limit - j.character_count,
    resets: j.next_character_count_reset_unix ? j.next_character_count_reset_unix * 1000 : null };
}
