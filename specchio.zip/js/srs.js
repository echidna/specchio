// Spaced repetition: FSRS-4.5 memory model with Anki-style learning steps.
// Ratings: 1 Again, 2 Hard, 3 Good, 4 Easy.

const W = [0.4872, 1.4003, 3.7145, 13.8206, 5.1618, 1.2298, 0.8975, 0.031, 1.6474,
  0.1367, 1.0461, 2.1072, 0.0793, 0.3246, 1.587, 0.2272, 2.8755];
const DECAY = -0.5;
const FACTOR = 19 / 81;
const RETENTION = 0.9;
const MAX_IVL = 365;
const MIN = 60 * 1000;
const DAY = 24 * 60 * MIN;
const LEARN_STEPS = [1 * MIN, 10 * MIN];
const RELEARN_STEPS = [10 * MIN];

const clamp = (x, a, b) => Math.min(b, Math.max(a, x));
const initD = r => clamp(W[4] - (r - 3) * W[5], 1, 10);
const initS = r => Math.max(W[r - 1], 0.1);

export function retrievability(elapsedDays, s) {
  return Math.pow(1 + FACTOR * elapsedDays / s, DECAY);
}

export function intervalDays(s) {
  const ivl = (s / FACTOR) * (Math.pow(RETENTION, 1 / DECAY) - 1);
  return clamp(Math.round(ivl), 1, MAX_IVL);
}

function nextD(d, r) {
  const d1 = d - W[6] * (r - 3);
  return clamp(W[7] * initD(4) + (1 - W[7]) * d1, 1, 10);
}

function recallS(d, s, R, r) {
  const hard = r === 2 ? W[15] : 1;
  const easy = r === 4 ? W[16] : 1;
  return s * (1 + Math.exp(W[8]) * (11 - d) * Math.pow(s, -W[9]) *
    (Math.exp(W[10] * (1 - R)) - 1) * hard * easy);
}

function forgetS(d, s, R) {
  const s2 = W[11] * Math.pow(d, -W[12]) * (Math.pow(s + 1, W[13]) - 1) * Math.exp(W[14] * (1 - R));
  return Math.min(s2, s);
}

// Review cards fall due at 4 a.m. local time on their due day, like Anki.
export function dayStart(ts) {
  const d = new Date(ts);
  if (d.getHours() < 4) d.setDate(d.getDate() - 1);
  d.setHours(4, 0, 0, 0);
  return d.getTime();
}
export function dayKey(ts) {
  const d = new Date(dayStart(ts));
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

export function newCard() {
  return { state: 'new', due: 0, s: 0, d: 0, step: 0, reps: 0, lapses: 0, last: 0 };
}

function graduate(c, now, r) {
  // keep Good/Easy intervals ordered
  let days = intervalDays(c.s);
  c.state = 'review';
  c.step = 0;
  c.due = dayStart(now) + days * DAY;
  c.ivl = days;
  return c;
}

// Returns a NEW card object; does not mutate the input.
export function schedule(card, r, now = Date.now()) {
  const c = { ...newCard(), ...card };
  c.reps += 1;

  if (c.state === 'new') {
    c.s = initS(r);
    c.d = initD(r);
    c.intro = now;
    c.last = now;
    if (r === 4) return graduate(c, now, r);
    c.state = 'learning';
    c.step = r === 3 ? 1 : 0;
    if (r === 3 && c.step >= LEARN_STEPS.length) return graduate(c, now, r);
    c.due = now + (r === 2 ? (LEARN_STEPS[0] + LEARN_STEPS[1]) / 2 : LEARN_STEPS[c.step]);
    return c;
  }

  if (c.state === 'learning' || c.state === 'relearning') {
    const steps = c.state === 'learning' ? LEARN_STEPS : RELEARN_STEPS;
    if (r === 1) {
      c.step = 0;
      c.due = now + steps[0];
    } else if (r === 2) {
      c.due = now + (c.step + 1 < steps.length ? (steps[c.step] + steps[c.step + 1]) / 2 : steps[c.step] * 1.5);
    } else if (r === 3) {
      c.step += 1;
      if (c.step >= steps.length) { c.last = now; return graduate(c, now, r); }
      c.due = now + steps[c.step];
    } else {
      c.s = Math.max(c.s, initS(4) * (c.state === 'learning' ? 1 : 0.5), c.s * 1.3);
      c.last = now;
      return graduate(c, now, r);
    }
    return c;
  }

  // review
  const elapsed = Math.max(0, (now - c.last) / DAY);
  const R = retrievability(elapsed, c.s);
  c.d = nextD(c.d, r);
  c.last = now;
  if (r === 1) {
    c.s = forgetS(c.d, c.s, R);
    c.lapses += 1;
    c.state = 'relearning';
    c.step = 0;
    c.due = now + RELEARN_STEPS[0];
    return c;
  }
  c.s = recallS(c.d, c.s, R, r);
  const prev = card.ivl || 1;
  let days = intervalDays(c.s);
  // keep Hard < Good < Easy and make progress on success
  if (r === 2) days = Math.max(1, Math.min(days, Math.round(prev * 1.2)));
  if (r >= 3) days = Math.max(days, prev + 1);
  days = Math.min(days, MAX_IVL);
  c.ivl = days;
  c.state = 'review';
  c.due = dayStart(now) + days * DAY;
  return c;
}

export function formatDelay(ms) {
  if (ms < 60 * MIN) return Math.max(1, Math.round(ms / MIN)) + 'm';
  if (ms < DAY) return Math.round(ms / (60 * MIN)) + 'h';
  const d = Math.round(ms / DAY);
  if (d < 31) return d + 'd';
  if (d < 365) return (d / 30).toFixed(d < 90 ? 1 : 0).replace('.0', '') + 'mo';
  return (d / 365).toFixed(1).replace('.0', '') + 'y';
}

export function previewIntervals(card, now = Date.now()) {
  return [1, 2, 3, 4].map(r => {
    const c = schedule(card, r, now);
    return formatDelay(c.state === 'review' ? c.due - dayStart(now) : c.due - now);
  });
}

export const LEARN_AHEAD = 20 * MIN;
export { DAY, MIN };
