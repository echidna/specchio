// Microphone recording. The mic is released after every take so iPhone playback
// returns to the loudspeaker at full volume.

const MAX_MS = 15000;

function pickType() {
  const types = ['audio/mp4', 'audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus'];
  if (typeof MediaRecorder === 'undefined') return '';
  return types.find(t => MediaRecorder.isTypeSupported?.(t)) || '';
}

export function micSupported() {
  return !!(navigator.mediaDevices?.getUserMedia && typeof MediaRecorder !== 'undefined');
}

export class Recorder {
  constructor(onLevel, onAutoStop) { this.onLevel = onLevel; this.onAutoStop = onAutoStop; this.active = false; }

  async start() {
    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: true },
    });
    const type = pickType();
    this.rec = new MediaRecorder(this.stream, type ? { mimeType: type } : undefined);
    this.chunks = [];
    this.rec.ondataavailable = e => e.data && e.data.size && this.chunks.push(e.data);
    this.done = new Promise(resolve => {
      this.rec.onstop = () => resolve(new Blob(this.chunks, { type: this.rec.mimeType || type || 'audio/mp4' }));
    });
    // live level meter
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      this.meterCtx = new AC();
      const src = this.meterCtx.createMediaStreamSource(this.stream);
      const an = this.meterCtx.createAnalyser();
      an.fftSize = 512;
      src.connect(an);
      const buf = new Float32Array(an.fftSize);
      const tick = () => {
        if (!this.active) return;
        an.getFloatTimeDomainData(buf);
        let m = 0;
        for (const v of buf) m = Math.max(m, Math.abs(v));
        this.onLevel?.(m);
        requestAnimationFrame(tick);
      };
      this.active = true;
      requestAnimationFrame(tick);
    } catch { this.active = true; }
    this.rec.start();
    this.timer = setTimeout(() => this.onAutoStop ? this.onAutoStop() : this.stop(), MAX_MS);
  }

  async stop() {
    if (!this.rec || this.rec.state === 'inactive') return this.done;
    clearTimeout(this.timer);
    this.active = false;
    this.rec.stop();
    const blob = await this.done;
    this.stream.getTracks().forEach(t => t.stop());
    try { await this.meterCtx?.close(); } catch { /* ignore */ }
    return blob;
  }
}
